﻿# TODO: Translation updated at 2026-10-15 10:57

# game/script.rpy:60
translate Spanish start_4f984941:

    # "The hallway buzzes with the unusual chaos as you walk to your next class..."
    "El pasillo bulle con un caos inusual mientras caminas hacia tu siguiente clase..."

# game/script.rpy:61
translate Spanish start_53163c51:

    # "You step into the classroom, the low murmur of students briefly quieting as all eyes shift toward you."
    "Entras en el aula, y el murmullo de los estudiantes se apaga un instante mientras todas las miradas se dirigen hacia ti."

# game/script.rpy:62
translate Spanish start_558d2478:

    # "You’re the new student."
    "Eres de nuevo ingreso."

# game/script.rpy:63
translate Spanish start_11fec560:

    # "All the faces look unfamiliar, some curious, others indifferent. You stand there awkwardly for a moment"
    "Todos los rostros te resultan desconocidos, algunos curiosos, otros indiferentes. Te quedas ahí un momento, sin saber qué hacer"

# game/script.rpy:69
translate Spanish start_63e56fa1:

    # "Ah! You must be the new student"
    "¡Ah! Debes de ser de nuevo ingreso"

# game/script.rpy:71
translate Spanish start_0c623f91:

    # "!"
    "!"

# game/script.rpy:73
translate Spanish start_4bca0030:

    # b "I'm Mr Brown, your teacher for the year!"
    b "¡Soy el Sr. Brown, tu profesor de este año!"

# game/script.rpy:78
translate Spanish start_5957977b:

    # b "I see, welcome to senior class of 2013, [povname]"
    b "Ya veo, te doy la bienvenida a la clase de último año de 2013, [povname]"

# game/script.rpy:80
translate Spanish start_6d5e019b:

    # pov "Thanks"
    pov "Gracias"

# game/script.rpy:82
translate Spanish start_3d72fbc7:

    # b "Then... You can sit next to Melody at the back"
    b "Entonces... Puedes sentarte junto a Melody, al fondo"

# game/script.rpy:91
translate Spanish start_0c623f91_1:

    # "!"
    "!"

# game/script.rpy:95
translate Spanish start_870ef98c:

    # pov "Uh.. you dropped your pen..-"
    pov "Eh... se te cayó el bolígrafo...-"

# game/script.rpy:102
translate Spanish start_881f001c:

    # pov "Here-"
    pov "Toma-"

# game/script.rpy:111
translate Spanish start_a20cefa7:

    # "..."
    "..."

# game/script.rpy:112
translate Spanish start_ab3b2d56:

    # "The guy in front of you turns slightly."
    "El chico de delante se gira un poco."

# game/script.rpy:114
translate Spanish start_d05ae07b:

    # "A cold stare meets yours."
    "Una mirada fría se cruza con la tuya."

# game/script.rpy:115
translate Spanish start_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:118
translate Spanish start_f7efb262:

    # pov "..Why's he staring at me like that."
    pov "..¿Por qué me mira así?"

# game/script.rpy:129
translate Spanish choices_ca5100ba:

    # "Pen..."
    "Bolígrafo..."

# game/script.rpy:145
translate Spanish choices1_a_b0e18055:

    # "You pass the pen to him"
    "Le pasas el bolígrafo"

# game/script.rpy:146
translate Spanish choices1_a_5c5d2ee7:

    # pov "Uhhm here you go.."
    pov "Ehm, toma.."

# game/script.rpy:147
translate Spanish choices1_a_a2a28a16:

    # "You give him an awkward smile"
    "Le dedicas una sonrisa incómoda"

# game/script.rpy:151
translate Spanish choices1_b_bf8bb8b2:

    # "You give him a weird look, ignoring him"
    "Le lanzas una mirada extraña y lo ignoras"

# game/script.rpy:157
translate Spanish choices1_common_8ccf1048:

    # "You walked to your seat"
    "Caminaste hasta tu asiento"

# game/script.rpy:161
translate Spanish choices1_common_8abe9016:

    # "weird guy.."
    "qué tipo más raro.."

# game/script.rpy:162
translate Spanish choices1_common_a20cefa7:

    # "..."
    "..."

# game/script.rpy:164
translate Spanish choices1_common_59fd08f0:

    # b "Okay everyone! Let's start today's lesson."
    b "¡Muy bien, todos! Empecemos la lección de hoy."

# game/script.rpy:166
translate Spanish choices1_common_309af931:

    # b "Insomnia... when sleep refuses to come, even when you're exhausted."
    b "Insomnio... cuando el sueño se niega a llegar, aunque el cuerpo ya no dé más."

# game/script.rpy:167
translate Spanish choices1_common_e449db3f:

    # b "Causes... a mix of stress, daily habits, and health issues"
    b "Causas... una mezcla de estrés, hábitos diarios y problemas de salud"

# game/script.rpy:177
translate Spanish choices1_common_7b4435ea:

    # "You usually sleep..."
    "Normalmente duermes..."

# game/script.rpy:191
translate Spanish sleep_3a4606c9:

    # "of course.."
    "claro.."

# game/script.rpy:202
translate Spanish sleep_0560befe:

    # b "And dreams..."
    b "Y los sueños..."

# game/script.rpy:203
translate Spanish sleep_27c21757:

    # b "People have spent centuries trying to explain them."
    b "Las personas han pasado siglos intentando explicarlos."

# game/script.rpy:204
translate Spanish sleep_93f043f9:

    # b "They are essentially stories and hallucinations your mind creates while you sleep, which can involve any of your senses and feel remarkably real"
    b "En esencia, son historias y alucinaciones que tu mente crea mientras duermes, y pueden involucrar cualquiera de tus sentidos y sentirse sorprendentemente reales"

# game/script.rpy:206
translate Spanish sleep_a20cefa7:

    # "..."
    "..."

# game/script.rpy:211
translate Spanish sleep_38d19cb5:

    # "You dream.."
    "Sueñas.."

# game/script.rpy:227
translate Spanish dream_a20cefa7:

    # "..."
    "..."

# game/script.rpy:234
translate Spanish dream_f5cd507b:

    # b "Whatever they are..."
    b "Sean lo que sean..."

# game/script.rpy:235
translate Spanish dream_e771e0ae:

    # b "One thing's certain."
    b "Hay algo seguro."

# game/script.rpy:237
translate Spanish dream_d6e76b0a:

    # b "Everyone dreams."
    b "Todos soñamos."

# game/script.rpy:239
translate Spanish dream_42532535:

    # b "Some say they're messages."
    b "Algunos dicen que son mensajes."

# game/script.rpy:240
translate Spanish dream_cff776d2:

    # b "Some say they're memories."
    b "Algunos dicen que son recuerdos."

# game/script.rpy:241
translate Spanish dream_67c0f86e:

    # b "Some say they're fate itself..."
    b "Algunos dicen que son el destino mismo..."

# game/script.rpy:243
translate Spanish dream_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:247
translate Spanish dream_26f879d5:

    # "you take an interest in Dreams"
    "empiezas a interesarte por los sueños"

# game/script.rpy:263
translate Spanish interest_cc901901:

    # pov "*sigh*"
    pov "*suspiro*"

# game/script.rpy:264
translate Spanish interest_199f6a36:

    # pov "What is this teacher even teaching?"
    pov "¿Pero qué demonios enseña este profesor?"

# game/script.rpy:265
translate Spanish interest_a20cefa7:

    # "..."
    "..."

# game/script.rpy:268
translate Spanish interest_c203d551:

    # "Maybe it's okay to rest my eyes for a bit..."
    "Quizá no pase nada si descanso un poco la vista..."

# game/script.rpy:277
translate Spanish interest_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:278
translate Spanish interest_8e874a47:

    # b "Some researchers believe dreams help the brain simulate possible future situations, allowing us to mentally prepare for events before they happen"
    b "Algunos investigadores creen que los sueños ayudan al cerebro a simular posibles situaciones futuras, lo que nos permite prepararnos mentalmente para los sucesos antes de que ocurran"

# game/script.rpy:291
translate Spanish interest_bbc38482:

    # "Hey, are you alright??"
    "Oye, ¿estás bien??"

# game/script.rpy:297
translate Spanish interest_07a804d5:

    # "Ugh my head..."
    "Ugh, mi cabeza..."

# game/script.rpy:301
translate Spanish interest_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:303
translate Spanish interest_ff9029a6:

    # pov "S-sorry?"
    pov "¿P-perdón?"

# game/script.rpy:306
translate Spanish interest_35788a74:

    # "You were sleeping and... well class already ended like 3 minutes ago"
    "Estabas durmiendo y... bueno, la clase terminó hace como 3 minutos"

# game/script.rpy:308
translate Spanish interest_f544f9f8:

    # pov "Oh.. thank you"
    pov "Ah... gracias"

# game/script.rpy:309
translate Spanish interest_daafc8fd:

    # pov "Uhm if you don't mind me asking, who are you?"
    pov "Eh... si no te molesta que pregunte, ¿quién eres?"

# game/script.rpy:312
translate Spanish interest_cd15114a:

    # "I'm"
    "Soy"

# game/script.rpy:313
translate Spanish interest_91748774:

    # m "Melody"
    m "Melody"

# game/script.rpy:316
translate Spanish interest_a32b036b:

    # m "It's your first day here right [povname]?"
    m "Es tu primer día aquí, ¿verdad, [povname]?"

# game/script.rpy:319
translate Spanish interest_d104f687:

    # pov "Yea.. I don't really have much friends yet"
    pov "Sí... todavía no tengo muchas amistades"

# game/script.rpy:326
translate Spanish choices2_c0ba92bc:

    # m "Ohh, thats alright"
    m "Ohh, no pasa nada"

# game/script.rpy:327
translate Spanish choices2_8a76088c:

    # m "Let's be friends then."
    m "Entonces, ¡hagamos amistad!"

# game/script.rpy:347
translate Spanish choices2_a_e62cf481:

    # pov "That would be good"
    pov "Eso estaría bien"

# game/script.rpy:348
translate Spanish choices2_a_6a9dc91a:

    # "Well it's not like i'm in the position to decline friends anyways.."
    "Bueno, tampoco es como si estuviera en posición de rechazar amistades..."

# game/script.rpy:351
translate Spanish choices2_a_a20cefa7:

    # "..."
    "..."

# game/script.rpy:354
translate Spanish choices2_a_3f82abc5:

    # m "Also, are you okay? You seemed a bit uncomfortable when you were sleeping."
    m "Además, ¿estás bien? Parecía que lo pasabas mal mientras dormías."

# game/script.rpy:357
translate Spanish choices2_a_a4101544:

    # m "Which is also kindaa why I woke you up.."
    m "Que, bueno, también es un poco la razón por la que te desperté.."

# game/script.rpy:360
translate Spanish choices2_a_c3ca3180:

    # pov "..."
    pov "..."

# game/script.rpy:364
translate Spanish choices2_a_4dcf5c77:

    # pov "It's.. fine, just one of those bad dreams"
    pov "Está... bien, solo uno de esos malos sueños"

# game/script.rpy:367
translate Spanish choices2_a_9d93c885:

    # m "Alright, I hope you feel better"
    m "Vale, espero que te sientas mejor"

# game/script.rpy:371
translate Spanish choices2_a_6d5e019b:

    # pov "Thanks"
    pov "Gracias"

# game/script.rpy:374
translate Spanish choices2_a_8561976a:

    # m "Hmmm if you have any question let me know"
    m "Mmm, si tienes alguna pregunta, avísame"

# game/script.rpy:377
translate Spanish choices2_a_a6d3d134:

    # pov "Sure"
    pov "Claro"

# game/script.rpy:378
translate Spanish choices2_a_f44f26b1:

    # pov "Then..."
    pov "Entonces..."

# game/script.rpy:409
translate Spanish sub_choices2_a_e35b83b7:

    # "Hmm I should at least try to get to know her, she seems nice"
    "Mmm, al menos debería intentar conocerla, parece simpática"

# game/script.rpy:410
translate Spanish sub_choices2_a_5ea17185:

    # pov "Uhmm what's your favourite colour Melody?"
    pov "Emm, ¿cuál es tu color favorito, Melody?"

# game/script.rpy:413
translate Spanish sub_choices2_a_2b1c4ae2:

    # m "Hmm I like pink!"
    m "¡Mmm, me gusta el rosa!"

# game/script.rpy:416
translate Spanish sub_choices2_a_5569c5c6:

    # pov "Ohh pink is a nice colour"
    pov "Ohh, el rosa es un bonito color"

# game/script.rpy:421
translate Spanish sub_choices2_b_9ccf420d:

    # "Are you always this cheerful?"
    "¿Siempre eres así de alegre?"

# game/script.rpy:424
translate Spanish sub_choices2_b_f22ac914:

    # m "Huh, am I? haha I get that a lot"
    m "¿Eh? ¿Yo? Jaja, me lo dicen mucho"

# game/script.rpy:433
translate Spanish sub_choices2_c_62d6ba83:

    # pov "Uhmm.. if you don't mind me asking.."
    pov "Emm... si no te molesta que pregunte.."

# game/script.rpy:434
translate Spanish sub_choices2_c_78640875:

    # pov "Who was that guy with the white hoodie...?"
    pov "¿Quién era ese chico de la sudadera blanca...?"

# game/script.rpy:435
translate Spanish sub_choices2_c_a20cefa7:

    # "..."
    "..."

# game/script.rpy:439
translate Spanish sub_choices2_c_48ae7b4f:

    # m "Oh.. you mean Jeffrey?"
    m "Oh... ¿te refieres a Jeffrey?"

# game/script.rpy:440
translate Spanish sub_choices2_c_d0aa2e8d:

    # m "Well...."
    m "Bueno...."

# game/script.rpy:443
translate Spanish sub_choices2_c_d23be973:

    # m "Him and his brother Liu moved here a couple of months back"
    m "Él y su hermano Liu se mudaron aquí hace un par de meses"

# game/script.rpy:449
translate Spanish sub_choices2_c_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:450
translate Spanish sub_choices2_c_d4413ac3:

    # "The air shifts slightly"
    "El aire cambia un poco"

# game/script.rpy:458
translate Spanish sub_choices2_c_67dc88ac:

    # m "And well... I've heard that him and his brother often got bullied by Randall and his friends..."
    m "Y bueno... he oído que a él y a su hermano los acosaban a menudo Randall y sus amigos..."

# game/script.rpy:459
translate Spanish sub_choices2_c_64802af6:

    # m "And.. ever since the recent altercation on the school bus with Randall's group"
    m "Y... desde la reciente pelea en el autobús escolar con el grupo de Randall"

# game/script.rpy:461
translate Spanish sub_choices2_c_db971f56:

    # m "Something happened... I'm not really sure what"
    m "Pasó algo... no sé muy bien qué"

# game/script.rpy:468
translate Spanish sub_choices2_c_d3aacda6:

    # m "W-well I always did find Jeffrey kinda scary, Liu was really nice though.. "
    m "B-bueno, siempre me pareció que Jeffrey daba algo de miedo, aunque Liu era muy amable.. "

# game/script.rpy:474
translate Spanish sub_choices2_c_f70bc175:

    # m "W-well anyways.. do you have any more questions?"
    m "B-bueno, en fin... ¿tienes más preguntas?"

# game/script.rpy:480
translate Spanish sub_choices2_d_30285ae4:

    # pov "Hmm, i'll let you know if I have any"
    pov "Mmm, te avisaré si tengo alguna"

# game/script.rpy:483
translate Spanish sub_choices2_d_e6e45cf2:

    # m "Alright cya [povname]!"
    m "¡Vale, nos vemos, [povname]!"

# game/script.rpy:491
translate Spanish choices2_b_dc69e786:

    # "Uhmmm.. I'm alright thanks"
    "Emmm.. estoy bien, gracias"

# game/script.rpy:492
translate Spanish choices2_b_f7829105:

    # "I think I can figure things out on my own"
    "Creo que puedo arreglármelas por mi cuenta"

# game/script.rpy:495
translate Spanish choices2_b_080ff2e7:

    # m "Ohh.."
    m "Ohh.."

# game/script.rpy:498
translate Spanish choices2_b_bf510f9c:

    # m "Cya around then I guess..."
    m "Entonces nos vemos por ahí, supongo..."

# game/script.rpy:505
translate Spanish choice2_common_a05adc6d:

    # "Well that was eventful-"
    "Bueno, eso sí que fue movido-"

# game/script.rpy:506
translate Spanish choice2_common_a20cefa7:

    # "..."
    "..."

# game/script.rpy:507
translate Spanish choice2_common_c588516a:

    # "Let's see"
    "A ver"

# game/script.rpy:508
translate Spanish choice2_common_1f4cbe45:

    # "My locker is.. locker 215? I think thats down there"
    "Mi casillero es... ¿el casillero 215? Creo que está por allá"

# game/script.rpy:510
translate Spanish choice2_common_868f2678:

    # "215..."
    "215..."

# game/script.rpy:511
translate Spanish choice2_common_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:512
translate Spanish choice2_common_2f7d5ad1:

    # "...For a moment, you feel like someone is watching you."
    "...Por un momento, sientes que alguien te está observando."

# game/script.rpy:513
translate Spanish choice2_common_7cc73755:

    # "You glance around."
    "Miras a tu alrededor."

# game/script.rpy:514
translate Spanish choice2_common_1717995c:

    # "No one is."
    "No hay nadie."

# game/script.rpy:515
translate Spanish choice2_common_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:528
translate Spanish locker_route_a_d98683b4:

    # "Hey!"
    "¡Oye!"

# game/script.rpy:531
translate Spanish locker_route_a_00d8e58d:

    # pov "H-huh"
    pov "¿E-eh?"

# game/script.rpy:532
translate Spanish locker_route_a_f6e31803:

    # "You're the new student right?"
    "Eres de nuevo ingreso, ¿verdad?"

# game/script.rpy:534
translate Spanish locker_route_a_e1838165:

    # pov "Yea, I transferred here today"
    pov "Sí, hoy me transferí aquí"

# game/script.rpy:536
translate Spanish locker_route_a_2ec6ecad:

    # bec "Right... I'm Becca."
    bec "Ya veo... Soy Becca."

# game/script.rpy:537
translate Spanish locker_route_a_ebd79f79:

    # bec "We have a couple classes together, I think."
    bec "Creo que compartimos un par de clases."

# game/script.rpy:540
translate Spanish locker_route_a_9c023d20:

    # bec "And wow—you're actually really pretty/good looking~."
    bec "Y vaya... en realidad tienes un aspecto muy atractivo~."

# game/script.rpy:541
translate Spanish locker_route_a_56645127:

    # bec "Like... not what I expected."
    bec "O sea... no es lo que esperaba."

# game/script.rpy:557
translate Spanish becca_a_e4f84cd8:

    # bec "..."
    bec "..."

# game/script.rpy:558
translate Spanish becca_a_8e554e88:

    # bec "What did you say"
    bec "¿Qué dijiste?"

# game/script.rpy:560
translate Spanish becca_a_604e7666:

    # bec "What's with these new entitled brats that keep joining."
    bec "¿Qué les pasa a los nuevos que no dejan de llegar, tan creídos y mimados?"

# game/script.rpy:562
translate Spanish becca_a_9a8db8ae:

    # bec "Seriously I can't take these sluts anymore"
    bec "En serio, ya no soporto más a estas zorras"

# game/script.rpy:564
translate Spanish becca_a_7b8e1128:

    # pov "S-stop!"
    pov "¡B-basta!"

# game/script.rpy:574
translate Spanish becca_b_a20cefa7:

    # "..."
    "..."

# game/script.rpy:575
translate Spanish becca_b_41161eef:

    # bec "Wow rude"
    bec "Vaya, qué falta de educación"

# game/script.rpy:579
translate Spanish becca_c_4316b101:

    # bec "Hmmm"
    bec "Mmm"

# game/script.rpy:585
translate Spanish becca_common_e79650f2:

    # bec "Anyways you're lost, aren't you?"
    bec "En fin, no sabes dónde estás, ¿verdad?"

# game/script.rpy:587
translate Spanish becca_common_719c0c09:

    # pov "Yea.. do you know where locker 215 is..?"
    pov "Sí... ¿sabes dónde está el casillero 215..?"

# game/script.rpy:589
translate Spanish becca_common_1815c178:

    # bec "Yea, follow me"
    bec "Sí, sígueme"

# game/script.rpy:592
translate Spanish becca_common_dd8275d4:

    # "Here, 215 right?"
    "Aquí está, ¿el 215, no?"

# game/script.rpy:593
translate Spanish becca_common_08004790:

    # pov "Yea, thanks"
    pov "Sí, gracias"

# game/script.rpy:596
translate Spanish becca_common_4781db84:

    # s "Look Becca"
    s "Mira, Becca"

# game/script.rpy:599
translate Spanish becca_common_785cec4b:

    # "Jeffrey?"
    "¿Jeffrey?"

# game/script.rpy:602
translate Spanish becca_common_1f9b69ca:

    # pov "Who's that guy behind him..?"
    pov "¿Quién es ese chico que está detrás de él..?"

# game/script.rpy:604
translate Spanish becca_common_07f799c9:

    # bec "Randal?"
    bec "¿Randal?"

# game/script.rpy:606
translate Spanish becca_common_acc9cd66:

    # bec "Hmmm~"
    bec "Mmm~"

# game/script.rpy:612
translate Spanish becca_common_0e151b0c:

    # r "...You’ve been real quiet today huh?"
    r "...Hoy estás muy callado, ¿eh?"

# game/script.rpy:614
translate Spanish becca_common_80b0ce5a:

    # "Jeffrey doesn’t answer."
    "Jeffrey no responde."

# game/script.rpy:616
translate Spanish becca_common_3ceadf79:

    # r "What, no comeback?"
    r "¿Qué, no tienes respuesta?"

# game/script.rpy:617
translate Spanish becca_common_030d29a1:

    # "Randall tilts his head slightly."
    "Randall inclina ligeramente la cabeza."

# game/script.rpy:619
translate Spanish becca_common_1cee70c7:

    # r "That's new."
    r "Eso sí que es nuevo."

# game/script.rpy:621
translate Spanish becca_common_a20cefa7:

    # "..."
    "..."

# game/script.rpy:622
translate Spanish becca_common_b33f4840:

    # "Randall glances around, then back at him."
    "Randall mira a su alrededor y luego vuelve a mirarlo."

# game/script.rpy:624
translate Spanish becca_common_379a9176:

    # r "Oh. Right."
    r "Ah. Claro."

# game/script.rpy:626
translate Spanish becca_common_8aa6c831:

    # r "I don't see your Brother anywhere!"
    r "¡No veo a tu hermano por ningún lado!"

# game/script.rpy:628
translate Spanish becca_common_5eb14b24:

    # r "Kinda different when he's not around, isn't it?"
    r "Cambia bastante la cosa cuando él no está cerca, ¿no?"

# game/script.rpy:629
translate Spanish becca_common_295be9d1:

    # "Jeffrey's grip tightens."
    "Jeffrey aprieta más fuerte."

# game/script.rpy:641
translate Spanish route_jeff_1_03223424:

    # "You stay silent"
    "Te quedas en silencio"

# game/script.rpy:643
translate Spanish route_jeff_1_fa261ca7:

    # bec "What?"
    bec "¿Qué?"

# game/script.rpy:644
translate Spanish route_jeff_1_b141e510:

    # bec "Scared?"
    bec "¿Miedo?"

# game/script.rpy:645
translate Spanish route_jeff_1_c0c5e1cd:

    # "People are starting to gather"
    "La gente empieza a reunirse"

# game/script.rpy:672
translate Spanish route_jeff_1_b9b755e5:

    # r "..."
    r "..."

# game/script.rpy:673
translate Spanish route_jeff_1_ad28190c:

    # r "F-fuck"
    r "M-mierda"

# game/script.rpy:674
translate Spanish route_jeff_1_d909ec7f:

    # r "B-"
    r "S-"

# game/script.rpy:675
translate Spanish route_jeff_1_699d9315:

    # r "Blood...?"
    r "¿S-sangre...?"

# game/script.rpy:676
translate Spanish route_jeff_1_366c29e7:

    # r "...Y-you're DEAD mutt"
    r "...T-tú estás MUERTO, chucho"

# game/script.rpy:677
translate Spanish route_jeff_1_db881017:

    # r "!"
    r "!"

# game/script.rpy:684
translate Spanish route_jeff_1_b1860385:

    # j "Heh"
    j "Je"

# game/script.rpy:687
translate Spanish route_jeff_1_9610eb67:

    # j "Hehehehehe"
    j "Jejejejeje"

# game/script.rpy:689
translate Spanish route_jeff_1_57fd6b6b:

    # "Randall stumbles back, voice cracking."
    "Randall retrocede tambaleándose, con la voz quebrada."

# game/script.rpy:690
translate Spanish route_jeff_1_f1261b11:

    # r "W-wait... Jeffrey- I was just messing around, alright? it wasn't that serious"
    r "E-espera... Jeffrey... solo estaba bromeando, ¿vale? No era para tanto"

# game/script.rpy:691
translate Spanish route_jeff_1_b9ea9ced:

    # "Jeffrey doesn't respond."
    "Jeffrey no responde."

# game/script.rpy:693
translate Spanish route_jeff_1_331fd7af:

    # "He just keeps walking."
    "Simplemente sigue caminando."

# game/script.rpy:695
translate Spanish route_jeff_1_a20cefa7:

    # "..."
    "..."

# game/script.rpy:697
translate Spanish route_jeff_1_f5ec5174:

    # "Becca screams."
    "Becca grita."

# game/script.rpy:698
translate Spanish route_jeff_1_dbfd7432:

    # "The sound cuts through everything."
    "El sonido atraviesa todo."

# game/script.rpy:699
translate Spanish route_jeff_1_4a761472:

    # "People start backing away, chairs scraping harshly against the floor as panic spreads through the room. Someone bumps into a locker, another nearly trips trying to get out—"
    "La gente empieza a retroceder, las sillas rechinan con dureza contra el suelo mientras el pánico se extiende por la sala. Alguien choca con un casillero, otro casi tropieza intentando salir—"

# game/script.rpy:700
translate Spanish route_jeff_1_4406ce6f:

    # "what the hell—?!, you think to yourself"
    "¿qué demonios—?!, piensas para ti"

# game/script.rpy:701
translate Spanish route_jeff_1_98a18f91:

    # "Before you can react someone pulls you away from the gathering crowd"
    "Antes de que puedas reaccionar, alguien te aparta de la multitud que se va reuniendo"

# game/script.rpy:707
translate Spanish route_jeff_1_c7564eca:

    # "Hey?? Are you okay?"
    "¡Oye! ¿Estás bien?"

# game/script.rpy:710
translate Spanish route_jeff_1_dbd9abda:

    # "Dang you have it rough... first day here and you're already associated with Randal-"
    "Uf, qué mala suerte... primer día aquí y ya te relacionan con Randal-"

# game/script.rpy:711
translate Spanish route_jeff_1_333a71c2:

    # "And that other guy- just as crazy i'd advise you to stay away from them..."
    "Y con ese otro tipo, igual de loco... te aconsejo que te alejes de ellos..."

# game/script.rpy:713
translate Spanish route_jeff_1_26dbdeb0:

    # pov "???"
    pov "???"

# game/script.rpy:714
translate Spanish route_jeff_1_4e09b328:

    # pov "Yea I guess..."
    pov "Sí, supongo..."

# game/script.rpy:715
translate Spanish route_jeff_1_f3d61eaf:

    # pov "These people are insane though.."
    pov "Aunque esta gente está loca.."

# game/script.rpy:716
translate Spanish route_jeff_1_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:717
translate Spanish route_jeff_1_d93f9a7f:

    # pov "Thanks i'm [povname] btw"
    pov "Gracias, por cierto, soy [povname]"

# game/script.rpy:720
translate Spanish route_jeff_1_dfaf5f6a:

    # st "Steph..."
    st "Steph..."

# game/script.rpy:726
translate Spanish route_jeff_1_54b07338:

    # s "Hey, newbie. have you seen Becca anywhere??!"
    s "Oye, tú. ¿Has visto a Becca por algún lado??!"

# game/script.rpy:728
translate Spanish route_jeff_1_f0e6ab74:

    # s "She ran off after that freak punched Randall"
    s "Salió corriendo después de que ese bicho raro golpeara a Randall"

# game/script.rpy:730
translate Spanish route_jeff_1_c55c352f:

    # pov "No... I-I got pulled away before I could see anything else"
    pov "No... m-me apartaron antes de que pudiera ver nada más"

# game/script.rpy:732
translate Spanish route_jeff_1_8315da46:

    # s "I'm just worried... that monsters gonna go after her next.."
    s "Solo estoy preocupada... de que ese monstruo vaya tras ella después.."

# game/script.rpy:734
translate Spanish route_jeff_1_af7be462:

    # "Steph raises an eyebrow"
    "Steph arquea una ceja"

# game/script.rpy:736
translate Spanish route_jeff_1_12a89a5f:

    # st "Weren't you the ones that initiated?"
    st "¿No fueron ustedes los que empezaron?"

# game/script.rpy:737
translate Spanish route_jeff_1_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:738
translate Spanish route_jeff_1_126a0e7c:

    # st "But I do admit.. that guy looked kinda scary when he finally snapped"
    st "Pero admito... que ese chico daba bastante miedo cuando por fin explotó"

# game/script.rpy:740
translate Spanish route_jeff_1_782ccbf7:

    # st "At least Randall finally got what he deserved"
    st "Al menos Randall por fin recibió lo que merecía"

# game/script.rpy:742
translate Spanish route_jeff_1_9c8446f5:

    # s "You better watch your fucking tone band freak."
    s "Más te vale cuidar tu maldito tono, friki de la banda."

# game/script.rpy:743
translate Spanish route_jeff_1_ddf05079:

    # s "And obviously we didn't think that weirdo would fight back."
    s "Y, obviamente, no pensamos que ese bicho raro fuera a defenderse."

# game/script.rpy:744
translate Spanish route_jeff_1_a20cefa7_3:

    # "..."
    "..."

# game/script.rpy:747
translate Spanish route_jeff_1_2384fd4b:

    # st "..."
    st "..."

# game/script.rpy:749
translate Spanish route_jeff_1_8264115a:

    # st "Anyways... I better get to class, just ignore her."
    st "En fin... mejor me voy a clase, ignórala."

# game/script.rpy:750
translate Spanish route_jeff_1_89006540:

    # st "Be careful"
    st "Ten cuidado"

# game/script.rpy:753
translate Spanish route_jeff_1_77925b3c:

    # "That was... insane"
    "Eso fue... una locura"

# game/script.rpy:754
translate Spanish route_jeff_1_a00c1f69:

    # "I better get to class too I guess"
    "Supongo que yo también debería ir a clase"

# game/script.rpy:757
translate Spanish route_jeff_1_a20cefa7_4:

    # "..."
    "..."

# game/script.rpy:758
translate Spanish route_jeff_1_3383f94a:

    # "Jeffrey isn't here, nor is Randall or Becca..."
    "Jeffrey no está aquí, ni Randall ni Becca..."

# game/script.rpy:759
translate Spanish route_jeff_1_ca558359:

    # "Randall's probably in the nurse"
    "Randall probablemente esté en la enfermería"

# game/script.rpy:760
translate Spanish route_jeff_1_b59a996c:

    # "Seriously... who is this Jeffrey guy"
    "En serio... ¿quién es este tal Jeffrey?"

# game/script.rpy:761
translate Spanish route_jeff_1_a20cefa7_5:

    # "..."
    "..."

# game/script.rpy:762
translate Spanish route_jeff_1_e64c39c8:

    # "Whatever.. I should probably stay away from all three of them"
    "Da igual... lo mejor será mantener distancia con los tres"

# game/script.rpy:766
translate Spanish route_jeff_1_5f709240:

    # "It's a lot more quiet since the fight..."
    "Hay mucha más calma desde la pelea..."

# game/script.rpy:767
translate Spanish route_jeff_1_a20cefa7_6:

    # "..."
    "..."

# game/script.rpy:768
translate Spanish route_jeff_1_5694f2cf:

    # "Damn.. I feel bad for the cleaners"
    "Vaya... qué pena me dan los de limpieza"

# game/script.rpy:769
translate Spanish route_jeff_1_cf07e350:

    # "How gruesome..."
    "Qué espeluznante..."

# game/script.rpy:770
translate Spanish route_jeff_1_a20cefa7_7:

    # "..."
    "..."

# game/script.rpy:783
translate Spanish gore_fb153e92:

    # "You couldn't stand the sight of blood"
    "No soportabas la vista de la sangre"

# game/script.rpy:785
translate Spanish gore_58df24ca:

    # "That was you after all."
    "Así eras tú, después de todo."

# game/script.rpy:790
translate Spanish gore2_3b445ff0:

    # "You always felt a sense of fascination towards the sight of blood"
    "Siempre sentías fascinación al ver sangre"

# game/script.rpy:792
translate Spanish gore2_991301d4:

    # "that was you after all."
    "así eras tú, después de todo."

# game/script.rpy:794
translate Spanish gore2_f9200ee4:

    # "maybe you were just as crazy as these people.."
    "quizá a ti también te faltaba un tornillo, como a esta gente.."

# game/script.rpy:803
translate Spanish gat_1ff69aaa:

    # s "Hey.."
    s "Oye.."

# game/script.rpy:804
translate Spanish gat_e92fc8b5:

    # pov "Oh, hey"
    pov "Ah, hola"

# game/script.rpy:805
translate Spanish gat_e1554201:

    # s "..."
    s "..."

# game/script.rpy:807
translate Spanish gat_03184a7c:

    # s "Bec wasn't here during class.."
    s "Bec no estuvo en clase.."

# game/script.rpy:809
translate Spanish gat_a522d834:

    # s "C-can you.. help me search for her with me?"
    s "¿P-puedes... ayudarme a buscarla?"

# game/script.rpy:819
translate Spanish route_sara_1_b1e08893:

    # "Yea sure.."
    "Sí, claro.."

# game/script.rpy:821
translate Spanish route_sara_1_9c9c31bc:

    # s "Good."
    s "Bien."

# game/script.rpy:822
translate Spanish route_sara_1_26dbdeb0:

    # pov "???"
    pov "???"

# game/script.rpy:823
translate Spanish route_sara_1_088e0eeb:

    # s "Anyways, we can ask Randall, maybe he'll know"
    s "En fin, podemos preguntarle a Randall, quizá él sepa"

# game/script.rpy:824
translate Spanish route_sara_1_c2fb1e18:

    # pov "seriously.."
    pov "en serio.."

# game/script.rpy:826
translate Spanish route_sara_1_97edd970:

    # s "What. you have a problem with that?"
    s "¿Qué? ¿Tienes algún problema con eso?"

# game/script.rpy:827
translate Spanish route_sara_1_c3ca3180:

    # pov "..."
    pov "..."

# game/script.rpy:828
translate Spanish route_sara_1_d849b6b4:

    # "Before you can respond sara drags you with her"
    "Antes de que puedas responder, Sara te arrastra con ella"

# game/script.rpy:835
translate Spanish route_sara_2_5c2fdded:

    # "I better go home"
    "Mejor me voy a casa"

# game/script.rpy:836
translate Spanish route_sara_2_968fa104:

    # pov "Sorry, but I really should get going"
    pov "Lo siento, pero de verdad debería irme"

# game/script.rpy:837
translate Spanish route_sara_2_567d4842:

    # pov "I hope you'll be able to find her though..."
    pov "Aunque espero que logres encontrarla..."

# game/script.rpy:840
translate Spanish route_sara_2_ceaeca18:

    # s "What." with vpunch
    s "¿Qué?" with vpunch

# game/script.rpy:841
translate Spanish route_sara_2_0d7359e6:

    # s "You're coming with me to find her whether you like it or not, you're associated in this now. theres no backing out"
    s "Vas a venir conmigo a buscarla, quieras o no, ya eres parte de esto. No hay marcha atrás"

# game/script.rpy:842
translate Spanish route_sara_2_f66ae894:

    # s "Or should we just ruin your new little school life"
    s "¿O prefieres que te arruinemos tu nuevecita vida escolar?"

# game/script.rpy:843
translate Spanish route_sara_2_c3ca3180:

    # pov "..."
    pov "..."

# game/script.rpy:844
translate Spanish route_sara_2_d9d23c93:

    # pov "Okay okay i'll come along"
    pov "Vale, vale, te acompaño"

# game/script.rpy:845
translate Spanish route_sara_2_9c9c31bc:

    # s "Good."
    s "Bien."

# game/script.rpy:846
translate Spanish route_sara_2_26dbdeb0:

    # pov "???"
    pov "???"

# game/script.rpy:847
translate Spanish route_sara_2_088e0eeb:

    # s "Anyways, we can ask Randall, maybe he'll know"
    s "En fin, podemos preguntarle a Randall, quizá él sepa"

# game/script.rpy:848
translate Spanish route_sara_2_5527c2ff:

    # pov "Seriously.."
    pov "En serio.."

# game/script.rpy:850
translate Spanish route_sara_2_97edd970:

    # s "What. you have a problem with that?"
    s "¿Qué? ¿Tienes algún problema con eso?"

# game/script.rpy:851
translate Spanish route_sara_2_c3ca3180_1:

    # pov "..."
    pov "..."

# game/script.rpy:852
translate Spanish route_sara_2_d849b6b4:

    # "Before you can respond sara drags you with her"
    "Antes de que puedas responder, Sara te arrastra con ella"

# game/script.rpy:860
translate Spanish route_sara_common_745805b2:

    # s "We're here."
    s "Ya llegamos."

# game/script.rpy:864
translate Spanish route_sara_common_0715df49:

    # r "The fuck do you want"
    r "¿Qué carajo quieres?"

# game/script.rpy:865
translate Spanish route_sara_common_3b0daf1f:

    # r "Oh? Who's your new friend~?"
    r "¿Oh? ¿Y quién viene contigo~?"

# game/script.rpy:866
translate Spanish route_sara_common_a20cefa7:

    # "..."
    "..."

# game/script.rpy:869
translate Spanish route_sara_common_0f7f169e:

    # s "Wow Randy, that freak really screwed you over huh"
    s "Vaya, Randy, ese bicho raro sí que te dejó hecho un desastre, ¿eh?"

# game/script.rpy:871
translate Spanish route_sara_common_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:872
translate Spanish route_sara_common_29df59b4:

    # r "Bitch"
    r "Perra"

# game/script.rpy:873
translate Spanish route_sara_common_bea53fb3:

    # r "Anyways what do you want."
    r "En fin, ¿qué quieres?"

# game/script.rpy:875
translate Spanish route_sara_common_6dc26f17:

    # s "It's about Bec"
    s "Es sobre Bec"

# game/script.rpy:876
translate Spanish route_sara_common_736b7538:

    # s "She didn't come to class and she's not picking up my calls."
    s "No vino a clase y no contesta mis llamadas."

# game/script.rpy:877
translate Spanish route_sara_common_b8a6bbfe:

    # r "Huh? what are you tryna say"
    r "¿Eh? ¿Qué intentas decir?"

# game/script.rpy:878
translate Spanish route_sara_common_51880ac9:

    # s "I'm saying i'm worried.. what if Jeffrey did something to her"
    s "Digo que estoy preocupada.. ¿y si Jeffrey le hizo algo?"

# game/script.rpy:880
translate Spanish route_sara_common_17c962bd:

    # r "No way"
    r "Imposible"

# game/script.rpy:881
translate Spanish route_sara_common_b9b755e5:

    # r "..."
    r "..."

# game/script.rpy:884
translate Spanish route_sara_common_76daefa3:

    # r "Doesn't matter"
    r "No importa"

# game/script.rpy:886
translate Spanish route_sara_common_c8b5b630:

    # r "Not like he'll be able to do anything anymore after the party this week"
    r "Además, ya no podrá hacer nada después de la fiesta de esta semana"

# game/script.rpy:889
translate Spanish route_sara_common_ff15c496:

    # s "No way~ you guys are actually going through with the plan?"
    s "No me digas~, ¿de verdad van a seguir con el plan?"

# game/script.rpy:890
translate Spanish route_sara_common_b2167a70:

    # r "Yea Keith and Troy already have the bleach and alcohol ready"
    r "Sí, Keith y Troy ya tienen listos el cloro y el alcohol"

# game/script.rpy:891
translate Spanish route_sara_common_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:892
translate Spanish route_sara_common_1f477475:

    # "These people are insane.."
    "Esta gente está loca.."

# game/script.rpy:893
translate Spanish route_sara_common_83a909e0:

    # "You decide to leave before they notice you here again"
    "Decides irte antes de que vuelvan a notar que estás aquí"

# game/script.rpy:895
translate Spanish route_sara_common_3dc0d43f:

    # "Seriously"
    "En serio"

# game/script.rpy:896
translate Spanish route_sara_common_a20cefa7_3:

    # "..."
    "..."

# game/script.rpy:897
translate Spanish route_sara_common_72a99254:

    # "Bleach and alcohol...?"
    "¿Cloro y alcohol...?"

# game/script.rpy:898
translate Spanish route_sara_common_25db2d70:

    # "I should go home.. no ones here anymore"
    "Debería irme a casa.. ya no queda nadie"

# game/script.rpy:899
translate Spanish route_sara_common_1c951729:

    # "I didn't realise how late it was"
    "No me había dado cuenta de lo tarde que era"

# game/script.rpy:901
translate Spanish route_sara_common_9c059e02:

    # "!" with vpunch
    "!" with vpunch

# game/script.rpy:902
translate Spanish route_sara_common_31871cc7:

    # "What's he doing here??"
    "¿Qué hace él aquí??"

# game/script.rpy:903
translate Spanish route_sara_common_a20cefa7_4:

    # "..."
    "..."

# game/script.rpy:904
translate Spanish route_sara_common_19e8dff2:

    # "I should warn him about Randall"
    "Debería advertirle sobre Randall"

# game/script.rpy:917
translate Spanish route_warn_15bd241e:

    # pov "Jeffrey"
    pov "Jeffrey"

# game/script.rpy:918
translate Spanish route_warn_9c059e02:

    # "!" with vpunch
    "!" with vpunch

# game/script.rpy:921
translate Spanish route_warn_b4fa3fc0:

    # j "..."
    j "..."

# game/script.rpy:923
translate Spanish route_warn_296a9a63:

    # j "Oh.. it's you"
    j "Ah... eres tú"

# game/script.rpy:925
translate Spanish route_warn_96fb57d5:

    # j "?"
    j "?"

# game/script.rpy:927
translate Spanish route_warn_952724a8:

    # pov "Listen.. I know we don't even know each other that well but"
    pov "Escucha.. sé que ni siquiera nos conocemos tanto, pero"

# game/script.rpy:928
translate Spanish route_warn_ddd8a5a0:

    # pov "Randal and his friends are planning.. something during some party this week"
    pov "Randal y sus amigos están planeando.. algo para una fiesta de esta semana"

# game/script.rpy:929
translate Spanish route_warn_d5a00808:

    # pov "Something with bleach or alcohol I.. don't really know"
    pov "Algo con cloro o alcohol, yo.. no sé bien"

# game/script.rpy:930
translate Spanish route_warn_03a8c2c3:

    # pov "I just wanted to warn you.. since well it seemed like the right thing to do."
    pov "Solo quería avisarte.. porque, bueno, me pareció lo correcto."

# game/script.rpy:933
translate Spanish route_warn_b4fa3fc0_1:

    # j "..."
    j "..."

# game/script.rpy:936
translate Spanish route_warn_bb2562fe:

    # j "Isn't it your first day today?"
    j "¿No es tu primer día hoy?"

# game/script.rpy:937
translate Spanish route_warn_0734723a:

    # j "[povname]"
    j "[povname]"

# game/script.rpy:938
translate Spanish route_warn_9b6e4697:

    # pov "W-well.."
    pov "B-bueno.."

# game/script.rpy:940
translate Spanish route_warn_93458c6d:

    # j "Even so.."
    j "Aun así.."

# game/script.rpy:942
translate Spanish route_warn_122b9980:

    # j "'Seemed like the right thing to do'"
    j "'Me pareció lo correcto'"

# game/script.rpy:945
translate Spanish route_warn_ff93459a:

    # j "You think that? even after watching me beat him up?"
    j "¿Piensas eso? ¿Incluso después de verme darle una paliza?"

# game/script.rpy:962
translate Spanish route_jeff_yes_bc86d1ed:

    # pov "Yes"
    pov "Sí"

# game/script.rpy:964
translate Spanish route_jeff_yes_07b8adc7:

    # j "Oh?"
    j "¿Oh?"

# game/script.rpy:965
translate Spanish route_jeff_yes_41c33896:

    # j "Interesting.."
    j "Interesante.."

# game/script.rpy:966
translate Spanish route_jeff_yes_44be9a0d:

    # "Jeffrey grins."
    "Jeffrey sonríe con malicia."

# game/script.rpy:968
translate Spanish route_jeff_yes_c3ca3180:

    # pov "..."
    pov "..."

# game/script.rpy:971
translate Spanish route_jeff_yes_12fe8375:

    # j "They're always planning things."
    j "Siempre andan planeando cosas."

# game/script.rpy:972
translate Spanish route_jeff_yes_acc25c54:

    # j "Always talking like you can predict people."
    j "Siempre hablando como si se pudiera predecir a la gente."

# game/script.rpy:975
translate Spanish route_jeff_yes_10a8b14f:

    # j "but you can't."
    j "pero no se puede."

# game/script.rpy:977
translate Spanish route_jeff_yes_c0569467:

    # j "They just… panic when they lose control."
    j "Simplemente… entran en pánico cuando pierden el control."

# game/script.rpy:979
translate Spanish route_jeff_yes_87c7ded2:

    # j "Cowards."
    j "Cobardes."

# game/script.rpy:982
translate Spanish route_jeff_yes_9047614d:

    # pov "Yea.. they don't seem like very nice people"
    pov "Sí.. no parecen muy buenas personas"

# game/script.rpy:984
translate Spanish route_jeff_yes_c41801e9:

    # j "!"
    j "!"

# game/script.rpy:986
translate Spanish route_jeff_yes_5ebc83a4:

    # j "Hahahahaha"
    j "Jajajajaja"

# game/script.rpy:987
translate Spanish route_jeff_yes_8a28e195:

    # pov "Hey! don't laugh I'm only telling the truth"
    pov "¡Oye! No te rías, solo digo la verdad"

# game/script.rpy:988
translate Spanish route_jeff_yes_c3ca3180_1:

    # pov "..."
    pov "..."

# game/script.rpy:989
translate Spanish route_jeff_yes_b713b19d:

    # pov "Heheh"
    pov "Jeje"

# game/script.rpy:991
translate Spanish route_jeff_yes_7d6b4e80:

    # pov "Maybe we can be friends..?"
    pov "¿Quizá podamos hacer amistad..?"

# game/script.rpy:993
translate Spanish route_jeff_yes_b4fa3fc0:

    # j "..."
    j "..."

# game/script.rpy:995
translate Spanish route_jeff_yes_88a18cc4:

    # j "Friends..? Don't have many of those"
    j "¿Amistades..? No tengo muchas de esas"

# game/script.rpy:997
translate Spanish route_jeff_yes_9ed4b749:

    # pov "Let's be then"
    pov "Entonces hagámoslo"

# game/script.rpy:999
translate Spanish route_jeff_yes_34aed414:

    # pov "See you around Jeff"
    pov "Nos vemos, Jeff"

# game/script.rpy:1002
translate Spanish route_jeff_yes_db669e95:

    # j "Jeff.. I like that"
    j "Jeff.. me gusta"

# game/script.rpy:1013
translate Spanish route_jeff_no_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1017
translate Spanish route_jeff_no_e460e042:

    # pov "So much for warning him"
    pov "Vaya manera de advertirle"

# game/script.rpy:1023
translate Spanish route_warn_2_de9bdf4c:

    # "Nah I should probably go home instead"
    "Nah, mejor me voy a casa"

# game/script.rpy:1024
translate Spanish route_warn_2_b3cb0503:

    # "Besides.. I don't even know this guy"
    "Además.. ni siquiera conozco a este tipo"

# game/script.rpy:1029
translate Spanish route_jeff_common_1b3ce289:

    # "Finally i'm home"
    "Por fin estoy en casa"

# game/script.rpy:1030
translate Spanish route_jeff_common_979095fb:

    # "Didn't realise it was already night"
    "No me di cuenta de que ya era de noche"

# game/script.rpy:1031
translate Spanish route_jeff_common_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1032
translate Spanish route_jeff_common_d887c4d6:

    # "I should probably get some sleep"
    "Debería dormir un poco"

# game/script.rpy:1038
translate Spanish route_jeff_common_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:1078
translate Spanish common_3_6fd79a17:

    # mystery "[povname]"
    mystery "[povname]"

# game/script.rpy:1080
translate Spanish common_3_7a67408a:

    # "..." with vpunch
    "..." with vpunch

# game/script.rpy:1082
translate Spanish common_3_2137cac6:

    # pov "That dream again..."
    pov "Ese sueño otra vez..."

# game/script.rpy:1083
translate Spanish common_3_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1084
translate Spanish common_3_b0e95f90:

    # "It's already morning..."
    "Ya es de mañana..."

# game/script.rpy:1086
translate Spanish common_3_96e4bb55:

    # "Maybe I should take a short break from my classes"
    "Quizá debería tomarme un breve descanso de las clases"

# game/script.rpy:1087
translate Spanish common_3_268a314c:

    # "All this stress, and these weird dreams"
    "Todo este estrés, y estos sueños raros"

# game/script.rpy:1089
translate Spanish common_3_338655a5:

    # "I could do a short break.."
    "Podría tomarme un descanso corto.."

# game/script.rpy:1090
translate Spanish common_3_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:1105
translate Spanish parents_96607d1f:

    # "Yea.. that's always been the case huh"
    "Sí.. siempre ha sido así, ¿eh?"

# game/script.rpy:1106
translate Spanish parents_64916847:

    # "No one would go looking for me."
    "Nadie vendría a buscarme."

# game/script.rpy:1114
translate Spanish parents_5cd41537:

    # "One day passed"
    "Pasó un día"

# game/script.rpy:1116
translate Spanish parents_f1ccdf93:

    # "Most of the day was spent sleeping."
    "La mayor parte del día se fue durmiendo."

# game/script.rpy:1119
translate Spanish parents_65c32adf:

    # "The dreams kept coming."
    "Los sueños seguían llegando."

# game/script.rpy:1120
translate Spanish parents_41aa805f:

    # "Every night ended the same way."
    "Todas las noches terminaban igual."

# game/script.rpy:1122
translate Spanish parents_ecb65b0a:

    # "That feeling."
    "Esa sensación."

# game/script.rpy:1124
translate Spanish parents_f51f2454:

    # "Like I wasn't alone in my room."
    "Como si hubiera alguien más en mi habitación."

# game/script.rpy:1126
translate Spanish parents_697173be:

    # "That voice..."
    "Esa voz..."

# game/script.rpy:1127
translate Spanish parents_1e30eae5:

    # "I felt like I should've recognised it."
    "Sentía que debería haberla reconocido."

# game/script.rpy:1128
translate Spanish parents_197ece45:

    # "Maybe I am really going insane"
    "Quizá de verdad estoy perdiendo la cabeza"

# game/script.rpy:1130
translate Spanish parents_96ab81cd:

    # "I ignored every message from school."
    "Ignoré todos los mensajes del colegio."

# game/script.rpy:1131
translate Spanish parents_dae946dc:

    # "Eventually, I stopped checking my phone altogether."
    "Con el tiempo, dejé de mirar el teléfono por completo."

# game/script.rpy:1133
translate Spanish parents_75f71add:

    # "Before I realized it..."
    "Antes de darme cuenta..."

# game/script.rpy:1134
translate Spanish parents_d4bc589c:

    # "An entire week had passed."
    "Había pasado una semana entera."

# game/script.rpy:1135
translate Spanish parents_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1137
translate Spanish parents_f7f969ad:

    # pov "I guess.. I should get ready"
    pov "Supongo.. que debería prepararme"

# game/script.rpy:1140
translate Spanish parents_948915e0:

    # pov "Back again."
    pov "De vuelta otra vez."

# game/script.rpy:1141
translate Spanish parents_0d3175f5:

    # "The air feels heavier than usual."
    "El aire se siente más pesado de lo normal."

# game/script.rpy:1144
translate Spanish parents_a0e24427:

    # pov "Hey Mel, Steph"
    pov "Hola, Mel, Steph"

# game/script.rpy:1146
translate Spanish parents_0f82722f:

    # st "Hey [povname] haven't seen you in a week"
    st "Hola, [povname], hacía una semana que no te veía"

# game/script.rpy:1147
translate Spanish parents_814d3868:

    # pov "Yea haha"
    pov "Sí, jaja"

# game/script.rpy:1148
translate Spanish parents_c8ed6887:

    # pov "Anyways, why the sad face"
    pov "En fin, ¿por qué esa cara triste?"

# game/script.rpy:1151
translate Spanish parents_f6b11b57:

    # m "You haven't heard...?"
    m "¿No te has enterado...?"

# game/script.rpy:1152
translate Spanish parents_3e71b032:

    # pov "Well no.."
    pov "Pues no.."

# game/script.rpy:1153
translate Spanish parents_3907cb9a:

    # m "Last night at the party.. Randal and his friends went too far"
    m "Anoche en la fiesta.. Randal y sus amigos se pasaron de la raya"

# game/script.rpy:1154
translate Spanish parents_62ddd7c6:

    # m "There was an accident... with fire"
    m "Hubo un accidente... con fuego"

# game/script.rpy:1155
translate Spanish parents_4b23aa11:

    # m "Jeffrey's in the hospital"
    m "Jeffrey está en el hospital"

# game/script.rpy:1156
translate Spanish parents_c3ca3180:

    # pov "..."
    pov "..."

# game/script.rpy:1157
translate Spanish parents_3974a18e:

    # pov "W-what?"
    pov "¿Q-qué?"

# game/script.rpy:1159
translate Spanish parents_39cd8d95:

    # "Now that you think about it... Jeff is no where to be seen"
    "Ahora que lo piensas... a Jeff no se le ve por ningún lado"

# game/script.rpy:1171
translate Spanish worry_2_ad902f14:

    # pov "That's horrible!?"
    pov "¡¿Qué horror?!"

# game/script.rpy:1172
translate Spanish worry_2_07cd2ebf:

    # pov "Did Randal and his friends, get arrested??"
    pov "¿Randal y sus amigos fueron arrestados??"

# game/script.rpy:1173
translate Spanish worry_2_aa584fd9:

    # m "We're not really sure to be honest..."
    m "La verdad es que no lo sabemos con certeza..."

# game/script.rpy:1174
translate Spanish worry_2_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1175
translate Spanish worry_2_6cd2a084:

    # "This school really is insane..."
    "Este colegio de verdad está loco..."

# game/script.rpy:1179
translate Spanish worry_2_7ba9f4e8:

    # b "...Alright."
    b "...Muy bien."

# game/script.rpy:1180
translate Spanish worry_2_a06ae309:

    # b "Before we begin class today, I need everyone's attention."
    b "Antes de empezar la clase de hoy, necesito la atención de todos."

# game/script.rpy:1181
translate Spanish worry_2_c2489c9a:

    # "The room slowly falls silent."
    "La sala va quedando en silencio."

# game/script.rpy:1182
translate Spanish worry_2_bd696147:

    # b "As some of you may already know..."
    b "Como algunos de ustedes ya sabrán..."

# game/script.rpy:1183
translate Spanish worry_2_8c0bc0de:

    # b "There was a serious incident at a party last night involving several students from this school."
    b "Anoche hubo un incidente grave en una fiesta en el que estuvieron involucrados varios estudiantes de este colegio."

# game/script.rpy:1184
translate Spanish worry_2_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:1185
translate Spanish worry_2_8ea83448:

    # b "One student was severely injured during an altercation involving three male students."
    b "Un estudiante resultó gravemente herido durante una pelea en la que participaron tres estudiantes varones."

# game/script.rpy:1186
translate Spanish worry_2_6f081d98:

    # b "One of those students attends this class."
    b "Uno de esos estudiantes asiste a esta clase."

# game/script.rpy:1187
translate Spanish worry_2_50460d06:

    # "The atmosphere immediately becomes heavier."
    "El ambiente se vuelve de inmediato más pesado."

# game/script.rpy:1188
translate Spanish worry_2_43a7ff30:

    # "Nobody says anything."
    "Nadie dice nada."

# game/script.rpy:1189
translate Spanish worry_2_1f9d4f43:

    # b "There were also two female students present during the incident."
    b "También había dos estudiantes mujeres presentes durante el incidente."

# game/script.rpy:1190
translate Spanish worry_2_dd707799:

    # b "At this time, the school administration and authorities are still investigating exactly what occurred."
    b "En este momento, la administración del colegio y las autoridades aún investigan qué ocurrió exactamente."

# game/script.rpy:1192
translate Spanish worry_2_6373e0c2:

    # b "The injured student suffered significant burns and is currently recovering in the hospital."
    b "El estudiante herido sufrió quemaduras graves y actualmente se recupera en el hospital."

# game/script.rpy:1193
translate Spanish worry_2_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:1194
translate Spanish worry_2_c911db22:

    # b "I will not tolerate rumors, harassment, or students interfering with the investigation."
    b "No toleraré rumores, acoso ni que los estudiantes interfieran en la investigación."

# game/script.rpy:1195
translate Spanish worry_2_50bef30c:

    # b "If any of you know something important, report it privately."
    b "Si alguno de ustedes sabe algo importante, repórtenlo en privado."

# game/script.rpy:1203
translate Spanish worry_2_ff2d39df:

    # m "Hey [povname]"
    m "Oye, [povname]"

# game/script.rpy:1205
translate Spanish worry_2_79e357fb:

    # m "You've seemed kinda troubled recently"
    m "Últimamente parece que algo te preocupa"

# game/script.rpy:1206
translate Spanish worry_2_8fd82ca1:

    # m "sooo.."
    m "así que.."

# game/script.rpy:1207
translate Spanish worry_2_26da3584:

    # m "Steph and I were wondering if you wanted to come hang out with us? maybe at night since it's late night shopping"
    m "Steph y yo nos preguntábamos si querrías venir a pasar el rato con nosotras. Quizá de noche, ya que hay compras nocturnas"

# game/script.rpy:1209
translate Spanish worry_2_6a723bab:

    # pov "Sure! I'll meet you guys at **** then?"
    pov "¡Claro! ¿Entonces nos vemos en ****?"

# game/script.rpy:1212
translate Spanish worry_2_8c5dfb97:

    # m "Perfect"
    m "Perfecto"

# game/script.rpy:1215
translate Spanish worry_2_2de19ae0:

    # "I should probably put my books in my locker so my bag will be lighter"
    "Debería guardar mis libros en el casillero para que la mochila pese menos"

# game/script.rpy:1216
translate Spanish worry_2_be92e5ae:

    # "Maybe I'll get one item from the mall"
    "Quizá me compre algo en el centro comercial"

# game/script.rpy:1217
translate Spanish worry_2_9c9e9be8:

    # "I should get..."
    "Debería comprar..."

# game/script.rpy:1241
translate Spanish a11_c43af6cf:

    # "Some cute clothes would be nice"
    "Algo de ropa linda estaría bien"

# game/script.rpy:1245
translate Spanish a22_0ec8eee8:

    # "Some yummy snacks would be nice"
    "Unos snacks ricos estarían bien"

# game/script.rpy:1249
translate Spanish a33_18bdcc00:

    # "New shoes would be... handy"
    "Unos zapatos nuevos serían... prácticos"

# game/script.rpy:1253
translate Spanish a44_28b61589:

    # "I love a good historical manga"
    "Me encanta un buen manga histórico"

# game/script.rpy:1257
translate Spanish a55_1d2f1962:

    # "Jewellry would be nice"
    "Unas joyas estarían bien"

# game/script.rpy:1258
translate Spanish a55_73f97729:

    # "Could be handy"
    "Podría ser útil"

# game/script.rpy:1262
translate Spanish a66_f7ad14ee:

    # "Hmmm maybe I'll decide later actually"
    "Mmm, quizá lo decida después, la verdad"

# game/script.rpy:1267
translate Spanish a66_12678faa:

    # "How is it already this late..."
    "¿Cómo es que ya es tan tarde...?"

# game/script.rpy:1268
translate Spanish a66_dd36e32b:

    # "I should meet Steph and Melody at our spot-"
    "Debería encontrarme con Steph y Melody en nuestro lugar-"

# game/script.rpy:1269
translate Spanish a66_9c059e02:

    # "!" with vpunch
    "!" with vpunch

# game/script.rpy:1273
translate Spanish a66_2946dafa:

    # mystery "Did I scare you?" with vpunch
    mystery "¿Te asusté?" with vpunch

# game/script.rpy:1274
translate Spanish a66_c1381f21:

    # pov "What The Hell?!"
    pov "¡¿Qué demonios?!"

# game/script.rpy:1277
translate Spanish a66_0b076fee:

    # mystery "You're that new student, right?"
    mystery "Eres de nuevo ingreso, ¿verdad?"

# game/script.rpy:1279
translate Spanish a66_8cc74e14:

    # mystery "Already clinging to the popular kids."
    mystery "Y ya pegándote a los populares."

# game/script.rpy:1282
translate Spanish a66_aebaf952:

    # mystery "You make me sick."
    mystery "Me das asco."

# game/script.rpy:1283
translate Spanish a66_33f08ea6:

    # pov "N-no!"
    pov "¡N-no!"

# game/script.rpy:1284
translate Spanish a66_a8eb1931:

    # pov "You have it all wrong!"
    pov "¡Lo has entendido todo mal!"

# game/script.rpy:1287
translate Spanish a66_055f2514:

    # mystery "heheheh"
    mystery "jejejeje"

# game/script.rpy:1288
translate Spanish a66_0ddbeece:

    # mystery "GO TO SLEEP"
    mystery "VETE A DORMIR"

# game/script.rpy:1323
translate Spanish worry_1_6a971119:

    # pov "Is he alright?!..."
    pov "¡¿Él está bien?!..."

# game/script.rpy:1324
translate Spanish worry_1_fb5a146b:

    # pov "And what about Randal and his friends, they got arrested right?"
    pov "¿Y Randal y sus amigos? Los arrestaron, ¿verdad?"

# game/script.rpy:1325
translate Spanish worry_1_ad165e71:

    # m "... They got away, but due to an annonymous tip the police were called well before.. so they're searching for them now"
    m "... Escaparon, pero por un aviso anónimo se llamó a la policía mucho antes.. así que ahora los están buscando"

# game/script.rpy:1326
translate Spanish worry_1_0b019f04:

    # "Annonymous tip?"
    "¿Aviso anónimo?"

# game/script.rpy:1327
translate Spanish worry_1_ce137730:

    # "Was it because I warned Jeff?"
    "¿Fue porque le advertí a Jeff?"

# game/script.rpy:1328
translate Spanish worry_1_5d3ff09c:

    # "Why do I feel so worried"
    "¿Por qué siento tanta inquietud?"

# game/script.rpy:1332
translate Spanish worry_1_7ba9f4e8:

    # b "...Alright."
    b "...Muy bien."

# game/script.rpy:1333
translate Spanish worry_1_a06ae309:

    # b "Before we begin class today, I need everyone's attention."
    b "Antes de empezar la clase de hoy, necesito la atención de todos."

# game/script.rpy:1334
translate Spanish worry_1_c2489c9a:

    # "The room slowly falls silent."
    "La sala va quedando en silencio."

# game/script.rpy:1335
translate Spanish worry_1_bd696147:

    # b "As some of you may already know..."
    b "Como algunos de ustedes ya sabrán..."

# game/script.rpy:1336
translate Spanish worry_1_8c0bc0de:

    # b "There was a serious incident at a party last night involving several students from this school."
    b "Anoche hubo un incidente grave en una fiesta en el que estuvieron involucrados varios estudiantes de este colegio."

# game/script.rpy:1337
translate Spanish worry_1_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1338
translate Spanish worry_1_8ea83448:

    # b "One student was severely injured during an altercation involving three male students."
    b "Un estudiante resultó gravemente herido durante una pelea en la que participaron tres estudiantes varones."

# game/script.rpy:1339
translate Spanish worry_1_6f081d98:

    # b "One of those students attends this class."
    b "Uno de esos estudiantes asiste a esta clase."

# game/script.rpy:1340
translate Spanish worry_1_50460d06:

    # "The atmosphere immediately becomes heavier."
    "El ambiente se vuelve de inmediato más pesado."

# game/script.rpy:1341
translate Spanish worry_1_43a7ff30:

    # "Nobody says anything."
    "Nadie dice nada."

# game/script.rpy:1342
translate Spanish worry_1_1f9d4f43:

    # b "There were also two female students present during the incident."
    b "También había dos estudiantes mujeres presentes durante el incidente."

# game/script.rpy:1343
translate Spanish worry_1_dd707799:

    # b "At this time, the school administration and authorities are still investigating exactly what occurred."
    b "En este momento, la administración del colegio y las autoridades aún investigan qué ocurrió exactamente."

# game/script.rpy:1345
translate Spanish worry_1_6373e0c2:

    # b "The injured student suffered significant burns and is currently recovering in the hospital."
    b "El estudiante herido sufrió quemaduras graves y actualmente se recupera en el hospital."

# game/script.rpy:1346
translate Spanish worry_1_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:1347
translate Spanish worry_1_c911db22:

    # b "I will not tolerate rumors, harassment, or students interfering with the investigation."
    b "No toleraré rumores, acoso ni que los estudiantes interfieran en la investigación."

# game/script.rpy:1348
translate Spanish worry_1_50bef30c:

    # b "If any of you know something important, report it privately."
    b "Si alguno de ustedes sabe algo importante, repórtenlo en privado."

# game/script.rpy:1353
translate Spanish worry_1_577ea92e:

    # "Your eyes drift toward Jeffrey's empty seat."
    "Tu mirada se desvía hacia el asiento vacío de Jeffrey."

# game/script.rpy:1354
translate Spanish worry_1_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:1355
translate Spanish worry_1_50fc4e17:

    # pov "Jeff..."
    pov "Jeff..."

# game/script.rpy:1356
translate Spanish worry_1_08d76575:

    # pov "What happened to you.."
    pov "¿Qué te pasó..?"

# game/script.rpy:1357
translate Spanish worry_1_4310fc77:

    # "You mumble"
    "Murmuras"

# game/script.rpy:1358
translate Spanish worry_1_78b9167e:

    # "The last time you saw him was last week when you decided to be friends with him"
    "La última vez que lo viste fue la semana pasada, cuando decidiste trabar amistad con él"

# game/script.rpy:1361
translate Spanish worry_1_c4d14966:

    # "It's been 2 weeks now"
    "Ya han pasado 2 semanas"

# game/script.rpy:1362
translate Spanish worry_1_48c0d1c7:

    # "Randal and his friends are still missing"
    "Randal y sus amigos siguen desaparecidos"

# game/script.rpy:1364
translate Spanish worry_1_007f1888:

    # "And sometime during the second week..."
    "Y en algún momento de la segunda semana..."

# game/script.rpy:1366
translate Spanish worry_1_8a50a4f5:

    # "Jeffrey vanished from the hospital..."
    "Jeffrey desapareció del hospital..."

# game/script.rpy:1373
translate Spanish worry_1_ff2d39df:

    # m "Hey [povname]"
    m "Oye, [povname]"

# game/script.rpy:1375
translate Spanish worry_1_79e357fb:

    # m "You've seemed kinda troubled recently"
    m "Últimamente parece que algo te preocupa"

# game/script.rpy:1376
translate Spanish worry_1_8fd82ca1:

    # m "sooo.."
    m "así que.."

# game/script.rpy:1377
translate Spanish worry_1_26da3584:

    # m "Steph and I were wondering if you wanted to come hang out with us? maybe at night since it's late night shopping"
    m "Steph y yo nos preguntábamos si querrías venir a pasar el rato con nosotras. Quizá de noche, ya que hay compras nocturnas"

# game/script.rpy:1379
translate Spanish worry_1_6a723bab:

    # pov "Sure! I'll meet you guys at **** then?"
    pov "¡Claro! ¿Entonces nos vemos en ****?"

# game/script.rpy:1382
translate Spanish worry_1_8c5dfb97:

    # m "Perfect"
    m "Perfecto"

# game/script.rpy:1385
translate Spanish worry_1_2de19ae0:

    # "I should probably put my books in my locker so my bag will be lighter"
    "Debería guardar mis libros en el casillero para que la mochila pese menos"

# game/script.rpy:1386
translate Spanish worry_1_be92e5ae:

    # "Maybe I'll get one item from the mall"
    "Quizá me compre algo en el centro comercial"

# game/script.rpy:1387
translate Spanish worry_1_9c9e9be8:

    # "I should get..."
    "Debería comprar..."

# game/script.rpy:1411
translate Spanish a1_c43af6cf:

    # "Some cute clothes would be nice"
    "Algo de ropa linda estaría bien"

# game/script.rpy:1415
translate Spanish a2_0ec8eee8:

    # "Some yummy snacks would be nice"
    "Unos snacks ricos estarían bien"

# game/script.rpy:1419
translate Spanish a3_18bdcc00:

    # "New shoes would be... handy"
    "Unos zapatos nuevos serían... prácticos"

# game/script.rpy:1423
translate Spanish a4_28b61589:

    # "I love a good historical manga"
    "Me encanta un buen manga histórico"

# game/script.rpy:1427
translate Spanish a5_54feabe0:

    # "some video games would be cool!"
    "¡unos videojuegos estarían geniales!"

# game/script.rpy:1428
translate Spanish a5_73f97729:

    # "Could be handy"
    "Podría ser útil"

# game/script.rpy:1432
translate Spanish a6_f7ad14ee:

    # "Hmmm maybe I'll decide later actually"
    "Mmm, quizá lo decida después, la verdad"

# game/script.rpy:1438
translate Spanish a6_12678faa:

    # "How is it already this late..."
    "¿Cómo es que ya es tan tarde...?"

# game/script.rpy:1439
translate Spanish a6_dd36e32b:

    # "I should meet Steph and Melody at our spot-"
    "Debería encontrarme con Steph y Melody en nuestro lugar-"

# game/script.rpy:1440
translate Spanish a6_9c059e02:

    # "!" with vpunch
    "!" with vpunch

# game/script.rpy:1443
translate Spanish a6_007e8f88:

    # r "Well, well..."
    r "Vaya, vaya..."

# game/script.rpy:1444
translate Spanish a6_c2e22f0f:

    # r "Look what we have here."
    r "Mira lo que tenemos aquí."

# game/script.rpy:1446
translate Spanish a6_e60dfd16:

    # r "Our anonymous little tipster~"
    r "Nuestra pequeña fuente anónima~"

# game/script.rpy:1447
translate Spanish a6_ce433687:

    # r "How does it feel snitching to the cops.. hm?"
    r "¿Qué se siente soplarle todo a la policía.. eh?"

# game/script.rpy:1448
translate Spanish a6_71c68f1d:

    # pov "N-no it w-"
    pov "N-no, f-"

# game/script.rpy:1450
translate Spanish a6_3164a762:

    # r "Relax."
    r "Relájate."

# game/script.rpy:1452
translate Spanish a6_adbcee86:

    # r "I'm not gonna hurt you."
    r "No voy a hacerte daño."

# game/script.rpy:1454
translate Spanish a6_a5655215:

    # r "Just give you a little beating"
    r "Solo darte una pequeña paliza"

# game/script.rpy:1465
translate Spanish caught_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1478
translate Spanish chase_a41d1b93:

    # "Your body moves before your mind can catch up."
    "Tu cuerpo se mueve antes de que tu mente pueda reaccionar."

# game/script.rpy:1479
translate Spanish chase_df4280d3:

    # r "HEY—"
    r "¡OYE—!"

# game/script.rpy:1480
translate Spanish chase_7da6d5f8:

    # "You don't dare to turn around"
    "No te atreves a darte la vuelta"

# game/script.rpy:1482
translate Spanish chase_22a730e7:

    # "The sound of footsteps crashes behind you."
    "El estruendo de pasos retumba a tus espaldas."

# game/script.rpy:1483
translate Spanish chase_475b3cc8:

    # r "GET BACK HERE"
    r "¡VUELVE AQUÍ!"

# game/script.rpy:1486
translate Spanish chase_063d217a:

    # "The alley stretches ahead of you."
    "El callejón se extiende ante ti."

# game/script.rpy:1487
translate Spanish chase_b7b60abe:

    # "You turn the corner sharply."
    "Giras bruscamente en la esquina."

# game/script.rpy:1488
translate Spanish chase_190e28c7:

    # "left, right left, left"
    "izquierda, derecha izquierda, izquierda"

# game/script.rpy:1489
translate Spanish chase_ba041e0a:

    # "right left, right, right"
    "derecha izquierda, derecha, derecha"

# game/script.rpy:1490
translate Spanish chase_a97ab435:

    # "Didn't matter"
    "No importaba"

# game/script.rpy:1492
translate Spanish chase_06b7ce62:

    # "You didn't even know where you were going"
    "Ni siquiera sabías adónde ibas"

# game/script.rpy:1495
translate Spanish chase_a216df44:

    # "The sound of Randall's footsteps suddenly disappears."
    "El sonido de los pasos de Randall desaparece de repente."

# game/script.rpy:1498
translate Spanish chase_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1499
translate Spanish chase_073ddc50:

    # "But you keep running anyway."
    "Pero sigues corriendo de todos modos."

# game/script.rpy:1518
translate Spanish jeff_end_de6e23d8:

    # "You slow to a stop, trying to catch your breath."
    "Te detienes poco a poco, intentando recuperar el aliento."

# game/script.rpy:1520
translate Spanish jeff_end_0be263b5:

    # "The alley feels too quiet."
    "El callejón está demasiado silencioso."

# game/script.rpy:1522
translate Spanish jeff_end_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1524
translate Spanish jeff_end_ab2c101f:

    # "that feeling again..."
    "esa sensación otra vez..."

# game/script.rpy:1526
translate Spanish jeff_end_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:1527
translate Spanish jeff_end_977ad197:

    # "Didn't matter, you had to get out of there"
    "No importaba, tenías que salir de allí"

# game/script.rpy:1531
translate Spanish jeff_end_9c059e02:

    # "!" with vpunch
    "!" with vpunch

# game/script.rpy:1538
translate Spanish jeff_end_635e4fd2:

    # r "Where do you think you're going freak" with vpunch
    r "¿A dónde crees que vas, bicho raro?" with vpunch

# game/script.rpy:1541
translate Spanish jeff_end_7e402e90:

    # r "Don't think we'll just let you go that easily"
    r "No creas que te dejaremos ir tan fácilmente"

# game/script.rpy:1542
translate Spanish jeff_end_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:1543
translate Spanish jeff_end_b41b9ce0:

    # "Argh... my head, that bastard must've hit me with that bat"
    "Argh... mi cabeza, ese bastardo debió de golpearme con ese bate"

# game/script.rpy:1546
translate Spanish jeff_end_6683c93d:

    # "F-fuck.. I'm bleeding"
    "M-mierda.. estoy sangrando"

# game/script.rpy:1548
translate Spanish jeff_end_b079e5a3:

    # r "Hurts, right?"
    r "Duele, ¿verdad?"

# game/script.rpy:1550
translate Spanish jeff_end_06152efc:

    # "'Yea~ Thats what annoying insects get for messing with our business'" with vpunch
    "'Sí~ Eso es lo que reciben los insectos molestos que se meten en nuestros asuntos'" with vpunch

# game/script.rpy:1551
translate Spanish jeff_end_0c623f91:

    # "!"
    "!"

# game/script.rpy:1552
translate Spanish jeff_end_d8b38bce:

    # "You turn around"
    "Te giras"

# game/script.rpy:1555
translate Spanish jeff_end_00b566c7:

    # pov "Becca?"
    pov "¿Becca?"

# game/script.rpy:1558
translate Spanish jeff_end_eb070991:

    # bec "You really think you can tell on us and get away in one piece~?"
    bec "¿De verdad creías que podías delatarnos y salir de una pieza~?"

# game/script.rpy:1559
translate Spanish jeff_end_a20cefa7_3:

    # "..."
    "..."

# game/script.rpy:1560
translate Spanish jeff_end_6f59dcf6:

    # "It's pointless trying to reason.."
    "Es inútil intentar razonar.."

# game/script.rpy:1562
translate Spanish jeff_end_44f88f56:

    # pov "What did you do to Jeff."
    pov "¿Qué le hiciste a Jeff?"

# game/script.rpy:1564
translate Spanish jeff_end_9837d470:

    # bec "Jeff?"
    bec "¿Jeff?"

# game/script.rpy:1567
translate Spanish jeff_end_8c4aea78:

    # bec "Cute nickname for a psycho."
    bec "Qué apodo tan tierno para un psicópata."

# game/script.rpy:1568
translate Spanish jeff_end_a20cefa7_4:

    # "..."
    "..."

# game/script.rpy:1569
translate Spanish jeff_end_a0ccbc8a:

    # pov "P-please you have it all wrong"
    pov "P-por favor, lo estás entendiendo todo mal"

# game/script.rpy:1570
translate Spanish jeff_end_4d88831b:

    # pov "Let me go."
    pov "Déjame ir."

# game/script.rpy:1573
translate Spanish jeff_end_32ec184a:

    # bec "Aww, don't look so scared~"
    bec "Aww, no pongas esa cara de miedo~"

# game/script.rpy:1576
translate Spanish jeff_end_a7aefbdf:

    # bec "If we wanted you dead, you'd already be screaming."
    bec "Si quisiéramos acabar contigo, ya estarías gritando."

# game/script.rpy:1577
translate Spanish jeff_end_03456b4f:

    # bec "This is just a warning~"
    bec "Esto es solo una advertencia~"

# game/script.rpy:1579
translate Spanish jeff_end_5ce71993:

    # bec "Then again..."
    bec "Aunque bien pensado..."

# game/script.rpy:1581
translate Spanish jeff_end_b502481c:

    # bec "Dead people can't snitch."
    bec "Los muertos no pueden delatar."

# game/script.rpy:1585
translate Spanish jeff_end_1bf078de:

    # "The wooden bat presses harshly against your throat."
    "El bate de madera presiona con dureza contra tu garganta."

# game/script.rpy:1586
translate Spanish jeff_end_8061acb7:

    # "Panic surges through your body."
    "El pánico recorre tu cuerpo."

# game/script.rpy:1587
translate Spanish jeff_end_f4113cca:

    # "You try to pull away—"
    "Intentas apartarte—"

# game/script.rpy:1588
translate Spanish jeff_end_33a2b425:

    # "But the pressure only tightens."
    "Pero la presión solo aumenta."

# game/script.rpy:1590
translate Spanish jeff_end_a20cefa7_5:

    # "..."
    "..."

# game/script.rpy:1591
translate Spanish jeff_end_fd75143b:

    # pov "H-"
    pov "H-"

# game/script.rpy:1592
translate Spanish jeff_end_82a1e799:

    # pov "...H-help"
    pov "...A-ayuda"

# game/script.rpy:1598
translate Spanish jeff_end_a20cefa7_6:

    # "..."
    "..."

# game/script.rpy:1601
translate Spanish jeff_end_deac75e3:

    # "The pressure around your throat suddenly disappears."
    "La presión en tu garganta desaparece de repente."

# game/script.rpy:1602
translate Spanish jeff_end_f1a824f8:

    # "The bat slips away from your neck."
    "El bate se aparta de tu cuello."

# game/script.rpy:1609
translate Spanish jeff_end_1e01e2d7:

    # bec "W-wha"
    bec "¿Q-qué?"

# game/script.rpy:1615
translate Spanish jeff_end_1e78eb21:

    # "Something warm splatters across your face. again"
    "Algo cálido te salpica la cara. otra vez"

# game/script.rpy:1619
translate Spanish jeff_end_a20cefa7_7:

    # "..."
    "..."

# game/script.rpy:1626
translate Spanish jeff_end_f5dddd3f:

    # "Becca collapses onto the pavement, choking violently."
    "Becca se desploma sobre el pavimento, ahogándose violentamente."

# game/script.rpy:1627
translate Spanish jeff_end_6bf9fd75:

    # "Blood leaking from her disfigured body"
    "La sangre brota de su cuerpo desfigurado"

# game/script.rpy:1628
translate Spanish jeff_end_dcebbb6d:

    # "You shuffle back horrified... trying to catch your breath."
    "Retrocedes arrastrándote, con horror... intentando recuperar el aliento."

# game/script.rpy:1630
translate Spanish jeff_end_b5a78160:

    # pov "W-what...?"
    pov "¿Q-qué...?"

# game/script.rpy:1635
translate Spanish jeff_end_fbbd62f1:

    # r "B-Becca?!"
    r "¡¿B-Becca?!"

# game/script.rpy:1636
translate Spanish jeff_end_be47638c:

    # "The bat slips from Randall's hands."
    "El bate se resbala de las manos de Randall."

# game/script.rpy:1642
translate Spanish jeff_end_a20cefa7_8:

    # "..."
    "..."

# game/script.rpy:1645
translate Spanish jeff_end_a8416db6:

    # "you freeze"
    "te quedas inmóvil"

# game/script.rpy:1646
translate Spanish jeff_end_af8c46e2:

    # "Randall glances back once — then bolts, vanishing around the corner."
    "Randall mira atrás una sola vez — y sale disparado, desapareciendo tras la esquina."

# game/script.rpy:1648
translate Spanish jeff_end_5f9b772e:

    # "...."
    "...."

# game/script.rpy:1662
translate Spanish run_9b3223b0:

    # "You try to get up, but the pain of your head injury from earlier stops you"
    "Intentas levantarte, pero el dolor de la herida en la cabeza de antes te detiene"

# game/script.rpy:1663
translate Spanish run_6ff1ffaa:

    # "With the last bit of adrenaline you had left, you managed to get up and run."
    "Con la poca adrenalina que te quedaba, lograste levantarte y correr."

# game/script.rpy:1666
translate Spanish run_083ce38c:

    # "But something sharp stabs you hard in the chest."
    "Pero algo afilado se te clava con fuerza en el pecho."

# game/script.rpy:1676
translate Spanish stay_b68aa7db:

    # "You stay frozen on the ground. unable to move"
    "Te quedas inmóvil en el suelo. sin poder moverte"

# game/script.rpy:1677
translate Spanish stay_f87e5edc:

    # "You want to scream"
    "Quieres gritar"

# game/script.rpy:1678
translate Spanish stay_28806ac6:

    # "Please.. somebody help"
    "Por favor.. que alguien me ayude"

# game/script.rpy:1680
translate Spanish stay_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1691
translate Spanish stay_e3df1260:

    # mystery "C'mon don't be scared~"
    mystery "Vamos, no tengas miedo~"

# game/script.rpy:1693
translate Spanish stay_7456a5be:

    # mystery "Open your eyes"
    mystery "Abre los ojos"

# game/script.rpy:1702
translate Spanish stay_dce96504:

    # mystery "See???"
    mystery "¿¿¿Ves???"

# game/script.rpy:1703
translate Spanish stay_e37ce56e:

    # mystery "What's there to be afraid of."
    mystery "¿De qué hay que tener miedo?"

# game/script.rpy:1705
translate Spanish stay_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:1706
translate Spanish stay_fba31b7d:

    # pov "I-it's you..."
    pov "E-eres tú..."

# game/script.rpy:1708
translate Spanish stay_8029b5d2:

    # pov "Who are you."
    pov "¿Quién eres?"

# game/script.rpy:1712
translate Spanish stay_c0a4c997:

    # mystery "Don't tell me you don't recognise me. [povname]"
    mystery "No me digas que no me reconoces. [povname]"

# game/script.rpy:1713
translate Spanish stay_c3ca3180:

    # pov "..."
    pov "..."

# game/script.rpy:1714
translate Spanish stay_238ad35a:

    # "Your eyes settle on the man in front of you."
    "Tus ojos se posan en el hombre que tienes delante."

# game/script.rpy:1715
translate Spanish stay_b8148acc:

    # "Milky blue eyes stare back, unblinking. Pale skin, almost colourless."
    "Unos ojos azul lechoso te devuelven la mirada, sin pestañear. Piel pálida, casi sin color."

# game/script.rpy:1716
translate Spanish stay_5afb71b5:

    # "Dark hair falls messily across his face."
    "El cabello oscuro le cae desordenado sobre el rostro."

# game/script.rpy:1717
translate Spanish stay_b38b41b7:

    # "His smile feels wrong—too wide, carrying a faint metallic scent, as if it was freshly cut."
    "Su sonrisa resulta inquietante—demasiado ancha, con un leve olor metálico, como si estuviera recién cortada."

# game/script.rpy:1719
translate Spanish stay_73c0d6b7:

    # "He looked.."
    "Parecía.."

# game/script.rpy:1746
translate Spanish terrifying_4130f530:

    # "The look in his eyes made your stomach twist."
    "La mirada de sus ojos te revolvió el estómago."

# game/script.rpy:1747
translate Spanish terrifying_7badb0f9:

    # "For a moment, you're convinced he could kill you without a second thought."
    "Por un momento, no dudas de que podría matarte sin pensarlo dos veces."

# game/script.rpy:1751
translate Spanish broken_717b08ec:

    # "Something behind his eyes felt... fractured."
    "Algo detrás de sus ojos se sentía... quebrado."

# game/script.rpy:1752
translate Spanish broken_70049cf5:

    # "like someone who didn't belong anywhere."
    "como alguien que no pertenecía a ningún lugar."

# game/script.rpy:1756
translate Spanish unfamiliar_319256d9:

    # "Whoever stands before you felt like a complete stranger."
    "Quienquiera que esté frente a ti se sentía como un completo desconocido."

# game/script.rpy:1760
translate Spanish tired_183c5bae:

    # "Exhaustion hangs over him like a shadow."
    "El agotamiento pesa sobre él como una sombra."

# game/script.rpy:1761
translate Spanish tired_b0c40c46:

    # "Not the kind sleep could ever fix."
    "De esos que el sueño nunca podría remediar."

# game/script.rpy:1763
translate Spanish tired_53d79128:

    # "A deep sense of loneliness."
    "Una profunda sensación de soledad."

# game/script.rpy:1767
translate Spanish attractive_e8c43864:

    # "Despite everything, you can't bring yourself to look away."
    "A pesar de todo, no logras apartar la mirada."

# game/script.rpy:1768
translate Spanish attractive_b0e7de94:

    # "Something about him is unsettling... yet undeniably captivating."
    "Hay algo en él que inquieta... pero que cautiva innegablemente."

# game/script.rpy:1770
translate Spanish attractive_e3c155b6:

    # "Fuck.. maybe you're the insane one."
    "Mierda.. quizá eres tú quien ha perdido la cabeza."

# game/script.rpy:1774
translate Spanish familiar_d66cd25c:

    # "Like someone you barely recognized."
    "Como alguien a quien apenas reconocías."

# game/script.rpy:1775
translate Spanish familiar_0cb37fbc:

    # "You know that face."
    "Conoces ese rostro."

# game/script.rpy:1776
translate Spanish familiar_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1780
translate Spanish mutual_ce4e2a45:

    # "Didn't matter who he was."
    "No importaba quién fuera."

# game/script.rpy:1781
translate Spanish mutual_f1ce51fe:

    # "Regardless, he didn't look human, and you weren't going to stay to find out."
    "De todos modos, no parecía humano, y no pensabas quedarte a averiguarlo."

# game/script.rpy:1787
translate Spanish mutual_a9902f06:

    # pov "Have we... met before?"
    pov "¿Nos... hemos visto antes?"

# game/script.rpy:1790
translate Spanish mutual_a9ee67c9:

    # mystery "That's a funny question."
    mystery "Qué pregunta tan graciosa."

# game/script.rpy:1792
translate Spanish mutual_469f46d3:

    # pov "I-I think you're mistaking me for someone else."
    pov "C-creo que me confundes con otra persona."

# game/script.rpy:1794
translate Spanish mutual_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1795
translate Spanish mutual_c147f866:

    # mystery "Am I?"
    mystery "¿Ah, sí?"

# game/script.rpy:1800
translate Spanish mutual_ad929391:

    # "He leaned in close."
    "Se inclinó hacia ti."

# game/script.rpy:1801
translate Spanish mutual_a8d133a1:

    # "A faint scent clung to him—antiseptic, stale cigarette smoke... and something burnt beneath it."
    "Un leve olor se aferraba a él—antiséptico, humo rancio de cigarrillo... y algo quemado debajo."

# game/script.rpy:1804
translate Spanish mutual_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:1806
translate Spanish mutual_05b5d5e5:

    # mystery "Hehehehe"
    mystery "Jejejeje"

# game/script.rpy:1807
translate Spanish mutual_5150899c:

    # pov "What are you—"
    pov "¿Qué estás—"

# game/script.rpy:1811
translate Spanish mutual_1ca31b3b:

    # "He moves suddenly—too fast for how calm he looked a second ago."
    "Se mueve de golpe—demasiado rápido para lo tranquilo que se veía un segundo antes."

# game/script.rpy:1813
translate Spanish mutual_4462b3ae:

    # mystery "Shhhhh"
    mystery "Shhhhh"

# game/script.rpy:1816
translate Spanish mutual_281fe8b8:

    # mystery "It'll alll make sense soon."
    mystery "Todo tendrá sentido pronto."

# game/script.rpy:1817
translate Spanish mutual_6dc4db6d:

    # "He laughs under his breath, like it's funny you're still confused."
    "Se ríe por lo bajo, como si le divirtiera que sigas sin entender nada."

# game/script.rpy:1818
translate Spanish mutual_90178489:

    # "Then, he raises the knife"
    "Entonces, levanta el cuchillo"

# game/script.rpy:1820
translate Spanish mutual_1c855ad8:

    # pov "W-WAIT!!" with vpunch
    pov "¡E-ESPERA!!" with vpunch

# game/script.rpy:1824
translate Spanish mutual_987a9752:

    # mystery "What."
    mystery "¿Qué?"

# game/script.rpy:1826
translate Spanish mutual_adc31813:

    # pov "I-I remember."
    pov "M-me acuerdo."

# game/script.rpy:1827
translate Spanish mutual_0c57f97b:

    # pov "I know who you are"
    pov "Sé quién eres"

# game/script.rpy:1830
translate Spanish mutual_0ad1c747:

    # mystery "Oh?"
    mystery "¿Oh?"

# game/script.rpy:1831
translate Spanish mutual_aafcbce2:

    # "He tilts his head, watching you carefully."
    "Inclina la cabeza, observándote con atención."

# game/script.rpy:1834
translate Spanish mutual_8776f33e:

    # mystery "Go on."
    mystery "Continúa."

# game/script.rpy:1837
translate Spanish mutual_7a612f29:

    # mystery "Who am I?"
    mystery "¿Quién soy?"

# game/script.rpy:1854
translate Spanish die_0cfaf5ff:

    # pov "I-I don’t know…"
    pov "N-no lo sé…"

# game/script.rpy:1855
translate Spanish die_991f2b27:

    # pov "I was lying… I’m s-sorry."
    pov "Estaba mintiendo… l-lo siento."

# game/script.rpy:1857
translate Spanish die_ca904560:

    # pov "P-please… don’t kill me."
    pov "P-por favor… no me mates."

# game/script.rpy:1858
translate Spanish die_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1860
translate Spanish die_128532ec:

    # "He lowers his gaze, almost bored"
    "Baja la mirada, casi aburrido"

# game/script.rpy:1861
translate Spanish die_836a4ed9:

    # "He tilts his head slightly, like he’s deciding something uninteresting."
    "Inclina un poco la cabeza, como si decidiera algo sin importancia."

# game/script.rpy:1864
translate Spanish die_df4f7a46:

    # mystery "Heh… I hate liars y'know."
    mystery "Je… odio a los mentirosos, ¿sabes?"

# game/script.rpy:1876
translate Spanish bad_54641d69:

    # "You’re… one of Randal’s victims?"
    "¿Eres… una víctima de Randal?"

# game/script.rpy:1879
translate Spanish bad_4a0e8e69:

    # mystery "…Hah."
    mystery "…Ja."

# game/script.rpy:1880
translate Spanish bad_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1882
translate Spanish bad_f850e036:

    # mystery "Wrong answer!"
    mystery "¡Respuesta incorrecta!"

# game/script.rpy:1894
translate Spanish dead_49217307:

    # pov "You’re… a serial killer."
    pov "Eres… un asesino en serie."

# game/script.rpy:1896
translate Spanish dead_938f5e9d:

    # pov "…You are, right?"
    pov "…¿Lo eres, verdad?"

# game/script.rpy:1898
translate Spanish dead_c2017a91:

    # mystery "..."
    mystery "..."

# game/script.rpy:1899
translate Spanish dead_1a6a914d:

    # mystery "ding ding ding"
    mystery "ding ding ding"

# game/script.rpy:1900
translate Spanish dead_52d3a1b0:

    # mystery "heh"
    mystery "je"

# game/script.rpy:1902
translate Spanish dead_f850e036:

    # mystery "Wrong answer!"
    mystery "¡Respuesta incorrecta!"

# game/script.rpy:1914
translate Spanish good_ba216f3c:

    # "Ugh"
    "Ugh"

# game/script.rpy:1915
translate Spanish good_52f0a9c1:

    # pov "Look, I clearly don’t know who you are."
    pov "Mira, es evidente que no sé quién eres."

# game/script.rpy:1916
translate Spanish good_778df8da:

    # pov "Getting your victim to guess... Isn’t this kind of cliché?"
    pov "Hacer que tu víctima adivine... ¿no es algo cliché?"

# game/script.rpy:1918
translate Spanish good_ac270e70:

    # "A pause"
    "Una pausa"

# game/script.rpy:1921
translate Spanish good_4a0e8e69:

    # mystery "…Hah."
    mystery "…Ja."

# game/script.rpy:1922
translate Spanish good_670134e0:

    # mystery "Cliché?"
    mystery "¿Cliché?"

# game/script.rpy:1923
translate Spanish good_2dedf877:

    # "He leans in closer"
    "Se acerca más"

# game/script.rpy:1926
translate Spanish good_ad8bc484:

    # mystery "You’re in the wrong position to be judging this."
    mystery "No estás en posición de juzgar esto."

# game/script.rpy:1928
translate Spanish good_d0691051:

    # "He pulls out the knife again."
    "Vuelve a sacar el cuchillo."

# game/script.rpy:1929
translate Spanish good_39a085a2:

    # pov "W-wait!-" with vpunch
    pov "¡E-espera!-" with vpunch

# game/script.rpy:1930
translate Spanish good_ddf30e46:

    # "A sharp movement—"
    "Un movimiento brusco—"

# game/script.rpy:1931
translate Spanish good_d4de4e71:

    # "You twist away at the last second."
    "Te apartas de un giro en el último segundo."

# game/script.rpy:1933
translate Spanish good_b9cd657f:

    # "Metal cuts past too close, grazing you as you roll back."
    "El metal pasa demasiado cerca y te roza mientras ruedas hacia atrás."

# game/script.rpy:1936
translate Spanish good_20d35e2d:

    # "He missed by intches"
    "Falló por centímetros"

# game/script.rpy:1939
translate Spanish good_c2017a91:

    # mystery "..."
    mystery "..."

# game/script.rpy:1942
translate Spanish good_0245081c:

    # mystery "You know..."
    mystery "Sabes..."

# game/script.rpy:1945
translate Spanish good_2342484f:

    # mystery "Most people would've been dead already."
    mystery "La mayoría de la gente ya estaría muerta."

# game/script.rpy:1947
translate Spanish good_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1949
translate Spanish good_bbae3c52:

    # mystery "You're welcome, by the way."
    mystery "De nada, por cierto."

# game/script.rpy:1951
translate Spanish good_e2a92022:

    # pov "...W-what?"
    pov "...¿Q-qué?"

# game/script.rpy:1953
translate Spanish good_5938d4aa:

    # mystery "For saving you."
    mystery "Por salvarte."

# game/script.rpy:1954
translate Spanish good_ba5eba41:

    # mystery "You would've lasted what? Hah Another minute?"
    mystery "¿Cuánto habrías durado? ¿Ja? ¿Otro minuto?"

# game/script.rpy:1955
translate Spanish good_d94b0da7:

    # "he grins"
    "sonríe con malicia"

# game/script.rpy:1958
translate Spanish good_d29e2a36:

    # mystery "Pretty generous of me, don't you think?"
    mystery "Bastante generoso de mi parte, ¿no crees?"

# game/script.rpy:1959
translate Spanish good_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:1961
translate Spanish good_a28afaea:

    # "You've got to be kidding me."
    "Tiene que ser una broma."

# game/script.rpy:1963
translate Spanish good_564ea62d:

    # pov "Does it really matter?"
    pov "¿De verdad importa?"

# game/script.rpy:1965
translate Spanish good_b1d663a1:

    # pov "You're going to kill me anyway."
    pov "De todos modos me vas a matar."

# game/script.rpy:1966
translate Spanish good_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:1969
translate Spanish good_9d455b43:

    # mystery "You're right."
    mystery "Tienes razón."

# game/script.rpy:1970
translate Spanish good_a20cefa7_3:

    # "..."
    "..."

# game/script.rpy:1978
translate Spanish good_d1e9ba0e:

    # mystery "run"
    mystery "corre"

# game/script.rpy:1982
translate Spanish good_75c90c14:

    # "The word barely lands in your ears before your body moves on its own."
    "La palabra apenas llega a tus oídos antes de que tu cuerpo se mueva solo."

# game/script.rpy:1983
translate Spanish good_0089ce5d:

    # "'Run'"
    "'Corre'"

# game/script.rpy:1984
translate Spanish good_431a5641:

    # "He's going to kill you."
    "Va a matarte."

# game/script.rpy:2007
translate Spanish m_5451db21:

    # "Your feet hit the ground hard."
    "Tus pies golpean el suelo con fuerza."

# game/script.rpy:2008
translate Spanish m_74c2c5c7:

    # "The pavement is uneven, cold under your shoes, but you don’t feel it properly."
    "El pavimento es irregular y frío bajo tus zapatos, pero no lo sientes bien."

# game/script.rpy:2009
translate Spanish m_d3a83d30:

    # "Your breath comes out in broken pulls, your lungs burn."
    "Tu respiración sale entrecortada, los pulmones te arden."

# game/script.rpy:2010
translate Spanish m_d8b84c61:

    # "But you don't stop to turn around."
    "Pero no te detienes a mirar atrás."

# game/script.rpy:2020
translate Spanish k_2302de96:

    # "Good you made it back here"
    "Bien, lograste volver aquí"

# game/script.rpy:2021
translate Spanish k_5451db21:

    # "Your feet hit the ground hard."
    "Tus pies golpean el suelo con fuerza."

# game/script.rpy:2022
translate Spanish k_74c2c5c7:

    # "The pavement is uneven, cold under your shoes, but you don’t feel it properly."
    "El pavimento es irregular y frío bajo tus zapatos, pero no lo sientes bien."

# game/script.rpy:2023
translate Spanish k_d3a83d30:

    # "Your breath comes out in broken pulls, your lungs burn."
    "Tu respiración sale entrecortada, los pulmones te arden."

# game/script.rpy:2024
translate Spanish k_d8b84c61:

    # "But you don't stop to turn around."
    "Pero no te detienes a mirar atrás."

# game/script.rpy:2029
translate Spanish haha_6e70ae04:

    # "You feel"
    "Sientes"

# game/script.rpy:2045
translate Spanish adr_1a05bfa4:

    # "Your body floods with heat as everything sharpens into focus."
    "Tu cuerpo se inunda de calor mientras todo se vuelve nítido."

# game/script.rpy:2046
translate Spanish adr_4cc2ff10:

    # "you haven't felt this way in a long time."
    "hacía mucho que no te sentías así."

# game/script.rpy:2047
translate Spanish adr_b1d92910:

    # "For a split second, it almost feels like freedom… before you remember you’re still running."
    "Por una fracción de segundo, casi parece libertad… hasta que recuerdas que sigues corriendo."

# game/script.rpy:2055
translate Spanish panic_2ea18d81:

    # "Your thoughts scatter like glass, too fast to catch. Breathing turns uneven as your mind struggles to decide what matters first."
    "Tus pensamientos se dispersan como cristales, demasiado rápidos para atraparlos. La respiración se vuelve irregular mientras tu mente se esfuerza por decidir qué importa primero."

# game/script.rpy:2056
translate Spanish panic_dc5fb7fc:

    # "for a second the alley feels… familiar, like a nightmare you’ve already lived through before."
    "por un segundo el callejón se siente… familiar, como una pesadilla que ya has vivido antes."

# game/script.rpy:2060
translate Spanish dread_069b8a14:

    # "It settles in slowly, like something already decided for you. You don’t just feel chased—you feel like something inevitable is catching up."
    "Se instala poco a poco, como algo que ya hubiera sido decidido de antemano. No solo sientes que te persiguen—sientes que algo inevitable te está alcanzando."

# game/script.rpy:2065
translate Spanish fear_ff42e5b3:

    # "A cold weight sinks into your chest, heavy and suffocating. Your instincts scream at you to run, even before you know where to go."
    "Un peso frío se hunde en tu pecho, pesado y asfixiante. Tus instintos te gritan que corras, incluso antes de saber adónde ir."

# game/script.rpy:2076
translate Spanish f_5eb2d21e:

    # "It locks into you instantly, heavy and suffocating, as the thought of not making it out alive becomes too real to ignore."
    "Se te clava al instante, pesado y asfixiante, mientras la idea de no salir con vida se vuelve demasiado real para ignorarla."

# game/script.rpy:2078
translate Spanish f_31264787:

    # "You fear death."
    "Temes a la muerte."

# game/script.rpy:2079
translate Spanish f_cc5f179f:

    # "No.. You can't die yet"
    "No.. No puedes morir todavía"

# game/script.rpy:2081
translate Spanish f_d154aec8:

    # "You have to make it out of here, no matter what."
    "Tienes que salir de aquí, cueste lo que cueste."

# game/script.rpy:2085
translate Spanish not_fear_6a33f729:

    # "Even with your heart racing, there’s a strange stillness in you—like survival matters more than the idea of dying, not the fear of it."
    "Aun con el corazón desbocado, hay una extraña calma en ti—como si sobrevivir importara más que la idea de morir, no el miedo a ella."

# game/script.rpy:2086
translate Spanish not_fear_cc5f179f:

    # "No.. You can't die yet"
    "No.. No puedes morir todavía"

# game/script.rpy:2088
translate Spanish not_fear_d154aec8:

    # "You have to make it out of here, no matter what."
    "Tienes que salir de aquí, cueste lo que cueste."

# game/script.rpy:2131
translate Spanish end_52ac482e:

    # mystery "Too slow!" with vpunch
    mystery "¡Muy lento!" with vpunch

# game/script.rpy:2132
translate Spanish end_78d6629f:

    # "Before you can react, your back hits the floor."
    "Antes de que puedas reaccionar, tu espalda golpea el suelo."

# game/script.rpy:2134
translate Spanish end_601a8e76:

    # "His weight keeps you there, as he laughs like a maniac."
    "Su peso te mantiene ahí, mientras ríe como un maníaco."

# game/script.rpy:2135
translate Spanish end_0ca4412b:

    # "One hand presses firmly against your throat, The other hangs above you, a knife held motionless."
    "Una mano presiona con firmeza tu garganta, la otra cuelga sobre ti, sosteniendo un cuchillo inmóvil."

# game/script.rpy:2136
translate Spanish end_a4711391:

    # pov "N-no nono"
    pov "N-no, no, no"

# game/script.rpy:2138
translate Spanish end_3b46d193:

    # "Raw fear settles across your face."
    "El miedo en estado puro se instala en tu rostro."

# game/script.rpy:2139
translate Spanish end_aedd2ad2:

    # "Tears sting your eyes."
    "Las lágrimas te escuecen en los ojos."

# game/script.rpy:2144
translate Spanish end_a20cefa7:

    # "..."
    "..."

# game/script.rpy:2148
translate Spanish end_1c195b53:

    # "The knife slowly lowers."
    "El cuchillo desciende lentamente."

# game/script.rpy:2149
translate Spanish end_69f61d37:

    # "His grip around your throat never loosens."
    "Su agarre en tu garganta nunca se afloja."

# game/script.rpy:2151
translate Spanish end_3e1560d9:

    # mystery "Don't look at me like that."
    mystery "No me mires así."

# game/script.rpy:2153
translate Spanish end_036c38d5:

    # mystery "I thought we were having a good time."
    mystery "Pensé que lo estábamos pasando bien."

# game/script.rpy:2157
translate Spanish end_50717c09:

    # "The grip around your neck tightens, cutting off what little air you had left."
    "El agarre en tu cuello se aprieta, cortando el poco aire que te quedaba."

# game/script.rpy:2160
translate Spanish end_d7ec9314:

    # mystery "[povname]."
    mystery "[povname]."

# game/script.rpy:2163
translate Spanish end_08310240:

    # pov "J-"
    pov "J-"

# game/script.rpy:2165
translate Spanish end_89ae8ebf:

    # pov "Jeff-"
    pov "Jeff-"

# game/script.rpy:2167
translate Spanish end_34fe138a:

    # pov "S-stop"
    pov "D-detente"

# game/script.rpy:2170
translate Spanish end_96fdc4d3:

    # "You force the words out, strained."
    "Fuerzas las palabras a salir, entrecortadas."

# game/script.rpy:2171
translate Spanish end_712d4ca8:

    # "Your glare locks onto him."
    "Tu mirada se clava en él."

# game/script.rpy:2176
translate Spanish end_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:2178
translate Spanish end_14cc7934:

    # "His grip loosens from your neck."
    "Su agarre se afloja en tu cuello."

# game/script.rpy:2180
translate Spanish end_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:2181
translate Spanish end_1f65f645:

    # mystery "You-"
    mystery "Tú-"

# game/script.rpy:2183
translate Spanish end_252c6325:

    # mystery "I don't understand at all."
    mystery "No entiendo nada."

# game/script.rpy:2187
translate Spanish end_6eef2008:

    # mystery "I-.."
    mystery "Yo-.."

# game/script.rpy:2195
translate Spanish end_c2017a91:

    # mystery "..."
    mystery "..."

# game/script.rpy:2199
translate Spanish end_179573b9:

    # mystery "Heh…"
    mystery "Je…"

# game/script.rpy:2202
translate Spanish end_88f053e6:

    # mystery "Didn’t think it’d end like this, did ya?"
    mystery "No pensabas que terminaría así, ¿verdad?"

# game/script.rpy:2205
translate Spanish end_a20cefa7_3:

    # "..."
    "..."

# game/script.rpy:2208
translate Spanish end_50d980e7:

    # mystery "But everyone close to me always dies."
    mystery "Pero todos los que están cerca de mí siempre mueren."

# game/script.rpy:2216
translate Spanish end_2807c2ec:

    # jeff "Go To Sleep"
    jeff "Vete a dormir"

# game/script.rpy:2229
translate Spanish end_d82feb71:

    # "Thank you for playing Chapter 1 Insomnia (DEMO)"
    "Gracias por jugar el Capítulo 1 Insomnia (DEMO)"

# game/script.rpy:2230
translate Spanish end_f2cbfa69:

    # "I truly appreciate you taking the time to experience this story. Every download, comment, share, and word of encouragement has helped keep this project alive."
    "Agradezco de verdad que te hayas tomado el tiempo de vivir esta historia. Cada descarga, comentario, compartido y palabra de ánimo ha ayudado a mantener vivo este proyecto."

# game/script.rpy:2231
translate Spanish end_5471ec4c:

    # "This is only the beginning. More chapters, artwork, and content may be planned, so stay tuned for future updates!"
    "Esto es solo el principio. Es posible que haya más capítulos, ilustraciones y contenido planeados, ¡así que no te pierdas las próximas actualizaciones!"

# game/script.rpy:2232
translate Spanish end_71fab998:

    # "If you'd like to support the development of Insomnia, consider Donating on the pop up screen after pressing 'Download'. Your support helps me continue creating new chapters and future visual novels faster."
    "Si quieres apoyar el desarrollo de Insomnia, considera donar en la ventana emergente que aparece después de pulsar 'Download'. Tu apoyo me ayuda a seguir creando nuevos capítulos y futuras novelas visuales más rápido."

# game/script.rpy:2330
translate Spanish route_jeff_2_5aa6e8e4:

    # "you laugh along with them"
    "te ríes con ellos"

# game/script.rpy:2332
translate Spanish route_jeff_2_566f8589:

    # bec "See?"
    bec "¿Ves?"

# game/script.rpy:2333
translate Spanish route_jeff_2_96d82f08:

    # bec "Even the new kid doesn't know what to make of you."
    bec "Hasta quien acaba de llegar no sabe qué pensar de ti."

# game/script.rpy:2334
translate Spanish route_jeff_2_2e7b33ea:

    # "people are starting to gather"
    "la gente empieza a reunirse"

# game/script.rpy:2361
translate Spanish route_jeff_2_b9b755e5:

    # r "..."
    r "..."

# game/script.rpy:2362
translate Spanish route_jeff_2_ad28190c:

    # r "F-fuck"
    r "M-mierda"

# game/script.rpy:2363
translate Spanish route_jeff_2_d909ec7f:

    # r "B-"
    r "S-"

# game/script.rpy:2364
translate Spanish route_jeff_2_699d9315:

    # r "Blood...?"
    r "¿S-sangre...?"

# game/script.rpy:2365
translate Spanish route_jeff_2_366c29e7:

    # r "...Y-you're DEAD mutt"
    r "...T-tú estás MUERTO, chucho"

# game/script.rpy:2366
translate Spanish route_jeff_2_db881017:

    # r "!"
    r "!"

# game/script.rpy:2370
translate Spanish route_jeff_2_97afa2a8:

    # j "heh"
    j "je"

# game/script.rpy:2373
translate Spanish route_jeff_2_50211d68:

    # j "hehehehehe"
    j "jejejejeje"

# game/script.rpy:2375
translate Spanish route_jeff_2_57fd6b6b:

    # "Randall stumbles back, voice cracking."
    "Randall retrocede tambaleándose, con la voz quebrada."

# game/script.rpy:2376
translate Spanish route_jeff_2_b6c4035e:

    # r "w-wait... Jeffrey- I was just messing around, alright? it wasn't that serious"
    r "e-espera... Jeffrey... solo estaba bromeando, ¿vale? no era para tanto"

# game/script.rpy:2377
translate Spanish route_jeff_2_b9ea9ced:

    # "Jeffrey doesn't respond."
    "Jeffrey no responde."

# game/script.rpy:2379
translate Spanish route_jeff_2_331fd7af:

    # "He just keeps walking."
    "Simplemente sigue caminando."

# game/script.rpy:2381
translate Spanish route_jeff_2_a20cefa7:

    # "..."
    "..."

# game/script.rpy:2383
translate Spanish route_jeff_2_f5ec5174:

    # "Becca screams."
    "Becca grita."

# game/script.rpy:2384
translate Spanish route_jeff_2_dbfd7432:

    # "The sound cuts through everything."
    "El sonido atraviesa todo."

# game/script.rpy:2385
translate Spanish route_jeff_2_0fb21b2e:

    # "People start backing away, chairs scraping harshly against the floor as panic spreads through the room. Someone bumps into a desk, another nearly trips trying to get out—"
    "La gente empieza a retroceder, las sillas rechinan con dureza contra el suelo mientras el pánico se extiende por la sala. Alguien choca con un pupitre, otro casi tropieza intentando salir—"

# game/script.rpy:2386
translate Spanish route_jeff_2_4406ce6f:

    # "what the hell—?!, you think to yourself"
    "¿qué demonios—?!, piensas para ti"

# game/script.rpy:2387
translate Spanish route_jeff_2_b8fa01ed:

    # "“stop— someone stop him!” someone in the crowd screams as jeff suddenly turns towards you"
    "“¡deténganlo— que alguien lo detenga!”, grita alguien entre la multitud mientras Jeff se gira de repente hacia ti"

# game/script.rpy:2391
translate Spanish route_jeff_2_b4fa3fc0:

    # j "..."
    j "..."

# game/script.rpy:2397
translate Spanish route_jeff_2_8048075a:

    # j "heh..."
    j "je..."

translate Spanish strings:

    # game/script.rpy:132
    old "Give him the pen"
    new "Darle el bolígrafo"

    # game/script.rpy:139
    old "Ignore him"
    new "Ignorarlo"

    # game/script.rpy:180
    old "well"
    new "bien"

    # game/script.rpy:183
    old "too much"
    new "demasiado"

    # game/script.rpy:186
    old "not enough."
    new "no lo suficiente."

    # game/script.rpy:213
    old "often"
    new "con frecuencia"

    # game/script.rpy:217
    old "sometimes"
    new "a veces"

    # game/script.rpy:220
    old "rarely"
    new "rara vez"

    # game/script.rpy:256
    old "not really"
    new "la verdad es que no"

    # game/script.rpy:337
    old "accept request"
    new "aceptar solicitud"

    # game/script.rpy:343
    old "decline request"
    new "rechazar solicitud"

    # game/script.rpy:383
    old "'What's your favourite colour?"
    new "¿Cuál es tu color favorito?"

    # game/script.rpy:386
    old "Are you always this cheerful?"
    new "¿Siempre eres así de alegre?"

    # game/script.rpy:389
    old "Who was that guy with the white hoodie?"
    new "¿Quién era ese chico de la sudadera blanca?"

    # game/script.rpy:392
    old "I'll let you know if I have any"
    new "Te avisaré si tengo alguna"

    # game/script.rpy:544
    old "Get lost"
    new "Lárgate"

    # game/script.rpy:547
    old "Thanks"
    new "Gracias"

    # game/script.rpy:550
    old "..."
    new "..."

    # game/script.rpy:633
    old "Stay silent"
    new "Quedarse en silencio"

    # game/script.rpy:637
    old "Laugh along"
    new "Reírse con ellos"

    # game/script.rpy:774
    old "The sight of gore scares you"
    new "Las imágenes sangrientas te asustan"

    # game/script.rpy:777
    old "You feel intrigued by the sight of gore"
    new "Sientes curiosidad por las imágenes sangrientas"

    # game/script.rpy:812
    old "Help sara search for Becca"
    new "Ayudar a Sara a buscar a Becca"

    # game/script.rpy:815
    old "Don't help sara"
    new "No ayudar a Sara"

    # game/script.rpy:907
    old "Warn Jeffrey about Randall's plan"
    new "Advertir a Jeffrey sobre el plan de Randall"

    # game/script.rpy:912
    old "Don't warn him about Randall"
    new "No advertirle sobre Randall"

    # game/script.rpy:949
    old "Yes"
    new "Sí"

    # game/script.rpy:953
    old "No"
    new "No"

    # game/script.rpy:1042
    old "Turn left"
    new "Girar a la izquierda"

    # game/script.rpy:1046
    old "Turn right"
    new "Girar a la derecha"

    # game/script.rpy:1095
    old "My parents are out of town"
    new "Mis padres están de viaje"

    # game/script.rpy:1098
    old "My parents don't live here"
    new "Mis padres no viven aquí"

    # game/script.rpy:1101
    old "My parents don't care"
    new "A mis padres no les importa"

    # game/script.rpy:1221
    old "Some cute clothes"
    new "Ropa linda"

    # game/script.rpy:1224
    old "Some delicious snacks"
    new "Unos snacks deliciosos"

    # game/script.rpy:1227
    old "Some new shoes"
    new "Unos zapatos nuevos"

    # game/script.rpy:1230
    old "Your favourite manga"
    new "Tu manga favorito"

    # game/script.rpy:1233
    old "Some jewellry"
    new "Unas joyas"

    # game/script.rpy:1236
    old "I'll decide later"
    new "Lo decidiré después"

    # game/script.rpy:1391
    old "Some cute/cool clothes"
    new "Ropa linda/genial"

    # game/script.rpy:1403
    old "Some video games"
    new "Unos videojuegos"

    # game/script.rpy:1457
    old "run"
    new "correr"

    # game/script.rpy:1460
    old "don't run"
    new "no correr"

    # game/script.rpy:1507
    old "turn left"
    new "girar a la izquierda"

    # game/script.rpy:1510
    old "turn right"
    new "girar a la derecha"

    # game/script.rpy:1658
    old "stay"
    new "quedarse"

    # game/script.rpy:1725
    old "Terrifying"
    new "Aterrador"

    # game/script.rpy:1728
    old "Broken"
    new "Roto"

    # game/script.rpy:1731
    old "Unfamiliar"
    new "Desconocido"

    # game/script.rpy:1734
    old "Tired"
    new "Cansado"

    # game/script.rpy:1737
    old "Strangely attractive..."
    new "Extrañamente atractivo..."

    # game/script.rpy:1740
    old "Like someone you barely recognized"
    new "Como alguien a quien apenas reconocías"

    # game/script.rpy:1841
    old "I don't know..."
    new "No lo sé..."

    # game/script.rpy:1844
    old "Retaliate"
    new "Contraatacar"

    # game/script.rpy:1847
    old "One of Randal's victims."
    new "Una víctima de Randal."

    # game/script.rpy:1850
    old "A serial killer"
    new "Un asesino en serie"

    # game/script.rpy:2032
    old "Adrenaline"
    new "Adrenalina"

    # game/script.rpy:2035
    old "Fear"
    new "Miedo"

    # game/script.rpy:2038
    old "Panic"
    new "Pánico"

    # game/script.rpy:2041
    old "Dread"
    new "Terror"

    # game/script.rpy:2067
    old "You fear death"
    new "Temes a la muerte"

    # game/script.rpy:2071
    old "You don't fear Death"
    new "No temes a la muerte"

    old "Oh, my name is.."
    new "Ah, mi nombre es..."
