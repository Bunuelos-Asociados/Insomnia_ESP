﻿# TODO: Translation updated at 2026-10-15 10:57

translate Spanish strings:

    # game/options.rpy:15
    old "Insomnia"
    new "Insomnia"

    # game/options.rpy:34
    old "Music I use: https://www.bensound.com License code: NBW7UGZ0FCIBJ4OX Artist: : Diffie Bosman\n\nMusic: Bensound.com/royalty-free-music License code: AHRUPOOJKJN32BD9 Artist: : FoePound\n\nMusic by Bensound.com/royalty-free-music License code: GLV6WWDOMQZDHOTZ Artist: : Benjamin Tissot\n\nMusic by <a href=\"https://pixabay.com/users/monume-44679891/?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=570702\">Monume</a> from <a href=\"https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=570702\">Pixabay</a>\n\n"
    new "Música que utilizo: https://www.bensound.com Código de licencia: NBW7UGZ0FCIBJ4OX Artista: : Diffie Bosman\n\nMúsica: Bensound.com/royalty-free-music Código de licencia: AHRUPOOJKJN32BD9 Artista: : FoePound\n\nMúsica de Bensound.com/royalty-free-music Código de licencia: GLV6WWDOMQZDHOTZ Artista: : Benjamin Tissot\n\nMúsica de <a href=\"https://pixabay.com/users/monume-44679891/?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=570702\">Monume</a> de <a href=\"https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=570702\">Pixabay</a>\n\n"

