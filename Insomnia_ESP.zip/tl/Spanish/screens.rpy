﻿translate Spanish strings:

    # game/screens.rpy:249
    old "Back"
    new "Atrás"

    # game/screens.rpy:250
    old "History"
    new "Historial"

    # game/screens.rpy:251
    old "Skip"
    new "Saltar"

    # game/screens.rpy:252
    old "Auto"
    new "Auto"

    # game/screens.rpy:253
    old "Save"
    new "Guardar"

    # game/screens.rpy:254
    old "Q.Save"
    new "G.Rápido"

    # game/screens.rpy:255
    old "Q.Load"
    new "C.Rápida"

    # game/screens.rpy:256
    old "Prefs"
    new "Opciones"

    # game/screens.rpy:302
    old "Start"
    new "Comenzar"

    # game/screens.rpy:310
    old "Load"
    new "Cargar"

    # game/screens.rpy:312
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:316
    old "Album"
    new "Álbum"

    # game/screens.rpy:320
    old "End Replay"
    new "Terminar repetición"

    # game/screens.rpy:324
    old "Main Menu"
    new "Menú principal"

    # game/screens.rpy:326
    old "About"
    new "Acerca de"

    # game/screens.rpy:331
    old "Help"
    new "Ayuda"

    # game/screens.rpy:337
    old "Quit"
    new "Salir"

    # game/screens.rpy:482
    old "Return"
    new "Volver"

    # game/screens.rpy:566
    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:572
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:608
    old "Page {}"
    new "Página {}"

    # game/screens.rpy:608
    old "Automatic saves"
    new "Guardados automáticos"

    # game/screens.rpy:608
    old "Quick saves"
    new "Guardados rápidos"

    # game/screens.rpy:650
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %d de %B de %Y, %H:%M"

    # game/screens.rpy:650
    old "empty slot"
    new "espacio vacío"

    # game/screens.rpy:670
    old "<"
    new "<"

    # game/screens.rpy:674
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:677
    old "{#quick_page}Q"
    new "{#quick_page}R"

    # game/screens.rpy:683
    old ">"
    new ">"

    # game/screens.rpy:688
    old "Upload Sync"
    new "Subir sincronización"

    # game/screens.rpy:692
    old "Download Sync"
    new "Descargar sincronización"

    # game/screens.rpy:752
    old "Display"
    new "Pantalla"

    # game/screens.rpy:753
    old "Window"
    new "Ventana"

    # game/screens.rpy:754
    old "Fullscreen"
    new "Pantalla completa"

    # game/screens.rpy:759
    old "Unseen Text"
    new "Texto no visto"

    # game/screens.rpy:760
    old "After Choices"
    new "Después de elegir"

    # game/screens.rpy:761
    old "Transitions"
    new "Transiciones"

    # game/screens.rpy:774
    old "Text Speed"
    new "Velocidad del texto"

    # game/screens.rpy:778
    old "Auto-Forward Time"
    new "Tiempo de avance automático"

    # game/screens.rpy:785
    old "Music Volume"
    new "Volumen de la música"

    # game/screens.rpy:792
    old "Sound Volume"
    new "Volumen de los efectos"

    # game/screens.rpy:798
    old "Test"
    new "Probar"

    # game/screens.rpy:802
    old "Voice Volume"
    new "Volumen de la voz"

    # game/screens.rpy:813
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:932
    old "The dialogue history is empty."
    new "El historial de diálogos está vacío."

    # game/screens.rpy:1000
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:1001
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:1004
    old "Gamepad"
    new "Mando"

    # game/screens.rpy:1017
    old "Enter"
    new "Enter"

    # game/screens.rpy:1018
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:1021
    old "Space"
    new "Espacio"

    # game/screens.rpy:1022
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:1025
    old "Arrow Keys"
    new "Flechas"

    # game/screens.rpy:1026
    old "Navigate the interface."
    new "Permiten navegar por la interfaz."

    # game/screens.rpy:1029
    old "Escape"
    new "Esc"

    # game/screens.rpy:1030
    old "Accesses the game menu."
    new "Accede al menú del juego."

    # game/screens.rpy:1033
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1034
    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se mantiene pulsada."

    # game/screens.rpy:1037
    old "Tab"
    new "Tab"

    # game/screens.rpy:1038
    old "Toggles dialogue skipping."
    new "Activa o desactiva el salto de diálogo."

    # game/screens.rpy:1041
    old "Page Up"
    new "Re Pág"

    # game/screens.rpy:1042
    old "Rolls back to earlier dialogue."
    new "Retrocede a diálogos anteriores."

    # game/screens.rpy:1045
    old "Page Down"
    new "Av Pág"

    # game/screens.rpy:1046
    old "Rolls forward to later dialogue."
    new "Avanza a diálogos posteriores."

    # game/screens.rpy:1050
    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1054
    old "Takes a screenshot."
    new "Hace una captura de pantalla."

    # game/screens.rpy:1058
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa o desactiva la {a=https://www.renpy.org/l/voicing}autolectura{/a} de asistencia."

    # game/screens.rpy:1062
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1068
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1072
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:1076
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1080
    old "Mouse Wheel Up"
    new "Rueda del ratón hacia arriba"

    # game/screens.rpy:1084
    old "Mouse Wheel Down"
    new "Rueda del ratón hacia abajo"

    # game/screens.rpy:1091
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    # game/screens.rpy:1095
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón superior izquierdo"

    # game/screens.rpy:1099
    old "Right Shoulder"
    new "Botón superior derecho"

    # game/screens.rpy:1103
    old "D-Pad, Sticks"
    new "Cruceta, palancas"

    # game/screens.rpy:1107
    old "Start, Guide, B/Right Button"
    new "Start, Guía, B/Botón derecho"

    # game/screens.rpy:1111
    old "Y/Top Button"
    new "Y/Botón superior"

    # game/screens.rpy:1114
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1226
    old "Skipping"
    new "Saltando"

    # game/screens.rpy:1540
    old "Menu"
    new "Menú"
